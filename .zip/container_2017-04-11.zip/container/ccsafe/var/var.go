// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package var provides a standardized interface to public variables, such
// as operation counters in servers.
//
// Operations to set or modify these public variables are atomic.
//
package Var

// Var is an abstract type - and a concept
//
// a Var is fmtFriendly, as it implements fmt.Stringer (by name)
//
// Just: to behave as a Var also implies: be concurrency safe!
//  this is achieved by use of "sync/atomic", or some higher
//  mechanisms from "sync" such as sync.Mutex or sync.RWMutex
//
// Note: Such concurrency safe atomic behaviour does not come for free. It implies:
//  Caveat: You may never copy such thing after first use!
//
// Hint: A convenience function - preferably named New - should be provided.
//  Note: "New" should return a pointer - which as such may freely be copied.
type Var interface {
	String() string
}

// JSONVar is an abstract type - and a concept
//
// String returns a valid JSON value for the Var.
//
// Note: Types with String methods that do not return valid JSON
// (such as time.Time) must not be used as a JSONVar.
type JSONVar interface {
	Var
}
