// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package string

import (
	"sync"
)

// String is a string variable, and satisfies the Var interface.
type String struct {
	mu sync.RWMutex
	s  string
	noCopy
}

func New(name string) *String {
	v := new(String)
	//	Publish(name, v)
	return v
}

func (v *String) Value() string {
	v.mu.RLock()
	defer v.mu.RUnlock()
	return v.s
}

func (v *String) String() string {
	return string(v.s)
}

func (v *String) Set(value string) {
	v.mu.Lock()
	defer v.mu.Unlock()
	v.s = value
}
