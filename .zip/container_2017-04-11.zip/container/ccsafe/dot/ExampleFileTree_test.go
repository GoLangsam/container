// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot_test

import (
	"path"
	"testing"

	"container/ccsafe/dot"
	do "do/dot"
)

// d.K = path, d.V = ext =>
//  - Dirs: (with FileInfo)
//  - Fils: (with ReadFile)
//  - Meta: (with *Template as parse of Extract(comment)
//  - Tmpl: (with *Template as parse of Fils.ReadFile
func lookAround(d *dot.Dot) *dot.Dot {

	do.ExecInfoWalk(d)     // => Dirs, Fils & Path
	d.Delete(do.Path.Id()) // forget other files

	for _, fil := range d.G(do.Fils.Id()).DownS() {
		do.ExecTagReadFile(fil)
		do.DoMetaParse(fil, d)
		do.DoTmplParse(fil, d)
	}
	return d
}

func TestFileTree(t *testing.T) {
	do.TmplFileExt = ".go"
	var FileTree = dot.New(path.Clean("../../")) // lets look a little higher
	FileTree.Tag(do.TmplFileExt)
	FileTree = lookAround(FileTree)
	FileTree = FileTree.PrintTree("File>>")
}
