// package fspath: file system path with os related functionalities
package fspath

import (
	"io/ioutil"
	"os"
	"path/filepath" // filepath.SplitList for NewS, and filepath.Glob for Glob
)

type FsPath struct {
	fspath string // file system path
}

// New returns a fresh FsPath representing some file system element (directory/file),
// regardless whether it exists, or not, or is even a pattern.
func New(path string) *FsPath {
	return &FsPath{path}
}

// String returns the pathtext repreented by FsPath
func (fp *FsPath) String() string {
	return fp.fspath
}

// NewS returns a non-empty slice of OsPath obtained via filepath.SplitList
func NewS(pathNames ...string) (pathS FsPathS) {
	/*
		for _, path := range dotpath.NewS(pathNames...) {
			pathS = append(pathS, OsPath{path})
		}
		return pathS
	*/
	if len(pathNames) < 1 {
		pathS = append(pathS, New(""))
	} else {
		for _, pathList := range pathNames {
			for _, pathName := range filepath.SplitList(pathList) {
				pathS = append(pathS, New(pathName))
			}
		}
	}
	return pathS
}

// Stat - returns the actual os.Stat() and the error received from os.Stat (of type *PathError)
//  Note: Stat does not refer to the FileInfo originally embedded into FsPath and thus may return
//  different FileInfo, if content of file system representetd by FsPath has changed.
func (fp *FsPath) Stat() (os.FileInfo, error) {
	fi, err := os.Stat(fp.fspath)
	return fi, err
}

// Join joins any number of path elements into a single path, adding a Separator if necessary.
// Join calls Clean on the result; in particular, all empty strings are ignored.
// On Windows, the result is a UNC path if and only if the first path element is a UNC path.
func (fp *FsPath) Join(elem ...string) string {
	e := make([]string, 0, len(elem)+1)
	e = append(e, fp.fspath)
	e = append(e, elem...)
	return filepath.Join(e...)
}

// Glob returns the names of all files matching the pattern (=PathText()),
// or nil if there is no matching entry(file/directory).
//  Note. The pattern may describe hierarchical names such as
//  /usr/*/bin/ed (assuming the Separator is '/').
//
// Glob ignores file system errors such as I/O errors reading directories.
// The only possible returned error is ErrBadPattern, when pattern is malformed.
//
//  Note: If FsPath does not exist, Glob may return matches, if FsPath represents a pattern.
//  If FsPath exists, Glob should return exactly one match: itself (unless Ospwd has changed).

func (fp *FsPath) Glob() (matches []string, err error) {
	matches, err = filepath.Glob(fp.fspath)
	return matches, err
}

// Accessible - returns nil, or the error received from os.Open (or Close)
func (fp *FsPath) Accessible() error {
	file, err := os.Open(fp.fspath)
	if err != nil {
		return err
	}
	return file.Close()
}

// MkDir uses os.MkdirAll to create a directory named by FsPath, along with any necessary parents,
// and returns nil, or else returns an error.
// The permission bits Perm are used for all created directories.
// If FsPath is already a directory, MkDir does nothing and returns nil.
func (fp *FsPath) MkDir() error {
	return os.MkdirAll(fp.fspath, Perm)
}

// Create creates the file named by OsPath.Path() with mode 0666 (before umask),
// truncating it if it already exists.
// If successful, methods on the returned File can be used for I/O;
// the associated file descriptor has mode O_RDWR.
// If there is an error, it will be of type *PathError.
//  Note: do not forget to defer file.Close()
func (fp *FsPath) Create() (*os.File, error) {
	file, err := os.Create(fp.fspath)
	return file, err
}

// Open opens the file named by OsPath.Path() for reading.
// If successful, methods on the returned file can be used for reading;
// the associated file descriptor has mode O_RDONLY.
// If there is an error, it will be of type *PathError.
//  Note: do not forget to defer file.Close()
func (fp *FsPath) Open() (*os.File, error) {
	file, err := os.Open(fp.fspath)
	return file, err
}

// ReadFile reads the file named by OsPath.Path() and returns the contents.
//  Note: A successful call returns err == nil, not err == EOF.
//  Because ReadFile reads the whole file, it does not treat an EOF from Read as an error to be reported.
//  Note: for convenience, the contents is returned as string, not as []byte.
func (fp *FsPath) ReadFile() ([]byte, error) {
	byteS, err := ioutil.ReadFile(fp.fspath)
	return byteS, err
}

// WriteFile writes data to a file named by FsPath.
// If the file does not exist, WriteFile creates it with permissions Perm;
// otherwise WriteFile truncates it before writing.
func (fp *FsPath) WriteFile(byteS []byte) error {
	return ioutil.WriteFile(fp.fspath, byteS, Perm)
}

// ReadDir reads the directory named by OsPath.Path() and returns a list of directory
// entries sorted by filename.
func (fp *FsPath) ReadDir() ([]os.FileInfo, error) {
	fiS, err := ioutil.ReadDir(fp.fspath)
	return fiS, err
}

/*
func TempDir(dir, prefix string) (name string, err error)
    TempDir creates a new temporary directory in the directory dir with a name
    beginning with prefix and returns the path of the new directory. If dir is
    the empty string, TempDir uses the default directory for temporary files
    (see os.TempDir). Multiple programs calling TempDir simultaneously will not
    choose the same directory. It is the caller's responsibility to remove the
    directory when no longer needed.

func TempFile(dir, prefix string) (f *os.File, err error)
    TempFile creates a new temporary file in the directory dir with a name
    beginning with prefix, opens the file for reading and writing, and returns
    the resulting *os.File. If dir is the empty string, TempFile uses the
    default directory for temporary files (see os.TempDir). Multiple programs
    calling TempFile simultaneously will not choose the same file. The caller
    can use f.Name() to find the pathname of the file. It is the caller's
    responsibility to remove the file when no longer needed.

*/
