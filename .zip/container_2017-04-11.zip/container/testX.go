// Copyright 2016 Andreas Pannewitz. All rights reserved.

package container

import (
	"fmt"
)

func main() {
	var game = new(list)
	game.root = "\n" + "Game"
	game.data = []string{"ONE", "TWO", "THREE"}

	var cols = new(list)
	cols.root = "Spalte"
	cols.data = []string{"A", "B", "C", "D", "E", "F", "G", "H"}

	var rows = new(list)
	rows.root = "\n" + "Zeile"
	rows.data = []string{"1", "2", "3", "4", "5", "6", "7", "8"}

	var null = new(list)
	fmt.Println(null)

	var board *list

	board = X(cols, rows) //
	fmt.Println(board)
	fmt.Println(len(board.data))

	board = X(rows, cols) //
	fmt.Println(board)
	fmt.Println(len(board.data))

	board = X(game, rows, cols) //
	fmt.Println(board)
	fmt.Println(len(board.data))

	board = X(game, cols, rows) //
	fmt.Println(board)
	fmt.Println(len(board.data))

}
