﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type extendableFriendly interface {
	Assignss(vals ...string) *StringMap            // Assign/overwrite Content with val - given as strings
	AssignMs(val ...map[string]string) *StringMap // Assign/overwrite Content with val - given as maps of strings
	AssignSs(val ...[]string) *StringMap          // Assign/overwrite Content with val - given as slices of strings
}

var _ extendableFriendly = New("Interface satisfied? :-)")

// Value modifiers - concurrency safe

func (d *StringMap) Assignss(vals ...string) *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range vals {
		d = d.add(v) // fullfill the promise
	}
	return d
}

func (d *StringMap) AssignMs(val ...map[string]string) *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range val {
		d = d.addM(v) // fullfill the promise
	}
	return d
}

func (d *StringMap) AssignSs(val ...[]string) *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, vals := range val {
		for _, v := range vals { // same as Assign()
			d = d.add(v) // fullfill the promise
		}
	}
	return d
}
