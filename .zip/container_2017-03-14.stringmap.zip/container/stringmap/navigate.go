﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type navigatorFriendly interface {
	parent() *StringMap
	Up() *StringMap
	Root() *StringMap
	Path() []*StringMap
	DownS() []*StringMap
}

var _ navigatorFriendly = New("Interface satisfied? :-)")

// Navigators - concurrency safe

// parent returns the parent (or nil, if at root)
func (d *StringMap) parent() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	return d.p
}

// Up returns the parent (or nil, if at root)
func (d *StringMap) Up() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	return d.p
}

// Root goes all the way Up() and returns the root - just in case You lost it :-)
func (d *StringMap) Root() *StringMap {
	// Note: our locking is delegated to up.parent()
	var root *StringMap
	for up := d; up != nil; up = up.parent() {
		root = up
	}
	return root
}

// Path returns a slice from here up to the root
// Note: as the slice is returned bottom-up, may like to reverse it :-)
func (d *StringMap) Path() []*StringMap {
	// Note: our locking is delegated to up.parent()
	var ups []*StringMap
	for up := d; up != nil; up = up.parent() {
		ups = append(ups, up)
	}
	return ups
}

func (d *StringMap) DownS() []*StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	var dns []*StringMap = make([]*StringMap, 0, d.Len())
	for _, key := range d.S() { // children
		dns = append(dns, d.getChild(key))
	}
	return dns
}
