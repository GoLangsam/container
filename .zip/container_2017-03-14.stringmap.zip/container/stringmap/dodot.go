﻿package stringmap

import (
	"do/dot"
)

// use package "path/filepath"

// filepath.Glob(path)
func (d *StringMap)AddFilePathGlob() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddFilePathGlob(d)
	return d

}

// filepath.Walk(path, WalkFunc)
func (d *StringMap)AddFileInfoWalk() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddFileInfoWalk(d)

	return d
}

// use package "io/ioutil"

// func ioutil.ReadFile(filename string) ([]byte, error)
func (d *StringMap)SetReadFile() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.SetReadFile(d)

	return d
}

// func ioutil.WriteFile(filename string, data []byte, perm os.FileMode) error
func (d *StringMap)DoWriteFile() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.DoWriteFile(d)

	return d
}

// func ioutil.ReadDir(dirname string) ([]os.FileInfo, error)
func (d *StringMap)AddReadDir() *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddReadDir(d)

	return d
}

/*

func TempDir(dir, prefix string) (name string, err error)
func TempFile(dir, prefix string) (f *os.File, err error)
*/