// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

import (
	"sync"

	"container/ccsafe/tag"
	"container/oldway/lsm"
)

var _ StringMapper = New("Interface satisfied?")

type StringMap struct {
	*tag.TagAny                     // key
	*lsm.LazyStringerMap            // value(s)
	p                    *StringMap // parent: Up(), Root(), Path(), DownS()
	home                 *StringMap // home - never changes
	sync.Mutex                      // concurency included
}

// New returns what You need in order to keep a hand on me :-)
func New(key string) *StringMap {
	dot := &StringMap{
		tag.New(key),     // init key
		lsm.New(),        // init val
		nil,              // no parent
		nil,              // no home
		*new(sync.Mutex), // mutex
	}
	dot.home = dot // home - never changes
	return dot
}

// A is a helper method for templates - it adds, and returns an empty string
func (d *StringMap) A(vals ...string) string {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range vals {
		d = d.add(v) // fullfill the promise
	}
	return ""
}

// G is a helper method for templates - it Get's the (eventually new!) child (key)
// change name to Dot? StringMap to Dots?
func (d *StringMap) G(key string) *StringMap {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	return d.getChild(key)
}

/*
Locking - handling with "do/dot"
All calls into "do/dot" have d.Lock()
All callbacks into StringMap used (via interface "do/dot.Dot")
are named "UnlockedXyz" and assume d.Lock is held
*/

// UnlockedGet is a helper method  - it returns the (eventually new!) child (key)
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *StringMap) UnlockedGet(key string) (interface{}, bool) {
	//	d.Lock()         // protect me, and ...
	//	defer d.Unlock() // release me, let me go ...
	c := d.getChild(key)
	return c, true // bool avoids usage from templates!
}

// UnlockedAdd adds key to d, and adds variadic strings below key, and returns child "key"
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *StringMap) UnlockedAdd(key string, val ...string) (interface{}, bool) {
	//	d.Lock()             // protect me, and ...
	//	defer d.Unlock()     // release me, let me go ...
	c := d.getChild(key) // get key
	c.Lock()             // protect it, and ...
	defer c.Unlock()     // release it, let it go ...
	c.add(val...)        // fullfill the promise
	return c, true       // bool avoids usage from templates!
}
