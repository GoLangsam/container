﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

import (
	"container/oldway/lsm"
	"container/ccsafe/tag"
)

/* TODO
doc.go
*/

type StringMapper interface {
	StringFriendly      // see below
	tag.Friendly        // via "pannewitz.com/container/tag"
	lsm.Friendly        // via "pannewitz.com/container/lsm"
//	userFriendly        // => dot!	extend.go: AddMap AddStrings AddStringS
	childrenFriendly    // children.go
	navigatorFriendly   // navigate.go: Up Root Path DownS
	privacyFriendly     // content.go
	printerFriendly     // print.go: PrintTree
	concurrencyFriendly // sync.go
//	ErrorFriendly       // => dot!	error.go
	goFriendly
	//	ChildrenS() []StringMapper
}

type StringFriendly interface {
	setableFriendly    // set.go: Set/replace Content: Set SetS SetM
	extendableFriendly // add.go: Add/overwrite Content: Add AddS AddM
	removeFriendly     // del.go: Delete/remove vals from Content
}

var _ StringFriendly = New("Interface satisfied?")

type goFriendly interface {
	//	Sort([]StringMapper)
}

var _ goFriendly = New("Interface satisfied?")
