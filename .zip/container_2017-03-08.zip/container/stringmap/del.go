// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type removeFriendly interface {
	Delete(vals ...string)            // Delete/remove val from Content
	DeleteM(val ...map[string]string) // Delete/remove val from Content - given as maps of strings
	DeleteS(val ...[]string)          // Delete/remove val from Content - given as slices of strings
}

var _ removeFriendly = New("Interface satisfied? :-)")

// Value modifiers - concurrency safe

func (d *StringMap) Delete(vals ...string) {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		d.Del(val)
	}
}

func (d *StringMap) DeleteM(vals ...map[string]string) {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		for k, v := range val {
			if c, ok := d.get(k); ok && c != nil { // for valid child k: delete v
				c.Del(v)
			}
		}
	}
}

func (d *StringMap) DeleteS(vals ...[]string) {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		for _, v := range val {
			d.Del(v)
		}
	}
}
