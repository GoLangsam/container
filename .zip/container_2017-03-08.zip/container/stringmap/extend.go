// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type userFriendly interface {
	AddMap(key string, vals ...map[string]string) StringMapper // returns the (eventually new) content named key after having applied AddM to it
	AddStrings(key string, val ...string) StringMapper         // returns the (eventually new) content named key after having applied AddS to it
	AddStringS(key string, val ...[]string) StringMapper       // returns the (eventually new) content named key after having applied AddS to it
}

var _ userFriendly = New("Interface satisfied? :-)")

// Creators - concurrency safe

// AddMap adds a named map to d and returns the (eventually new) content/child
func (d *StringMap) AddMap(key string, val ...map[string]string) StringMapper {
	d.Lock()             // protect me, and ...
	defer d.Unlock()     // release me, let me go ...
	c := d.getChild(key) // get key
	c.Lock()             // protect it, and ...
	defer c.Unlock()     // release it, let it go ...
	c.addM(val...)       // fullfill the promise
	return c
}

// AddStrings adds named variadic strings to d and returns the (eventually new) content/child
func (d *StringMap) AddStrings(key string, val ...string) StringMapper {
	d.Lock()             // protect me, and ...
	defer d.Unlock()     // release me, let me go ...
	c := d.getChild(key) // get key
	c.Lock()             // protect it, and ...
	defer c.Unlock()     // release it, let it go ...
	c.add(val...)        // fullfill the promise
	return c
}

// AddStringS adds named slices to content named key and returns the (eventually new) content/child
func (d *StringMap) AddStringS(key string, val ...[]string) StringMapper {
	d.Lock()             // protect me, and ...
	defer d.Unlock()     // release me, let me go ...
	c := d.getChild(key) // get key
	c.Lock()             // protect it, and ...
	defer c.Unlock()     // release it, let it go ...
	for _, vals := range val {
		c.add(vals...) // fullfill the promise
	}
	return c
}
