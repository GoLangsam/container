// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type setableFriendly interface {
	Set(vals ...string)            // Set/replace Content with val - given as strings
	SetM(val ...map[string]string) // Set/replace Content with val - given as maps of strings
	SetS(val ...[]string)          // Set/replace Content with val - given as slices of strings
}

var _ setableFriendly = New("Interface satisfied? :-)")

// Value modifiers - concurrency safe

func (d *StringMap) Set(vals ...string) {
	d.Lock()         // protect me, and ...
	d.Init()         // reset my being valueable, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range vals {
		d = d.add(v) // fullfill the promise
	}
}

func (d *StringMap) SetM(val ...map[string]string) {
	d.Lock()         // protect me, and ...
	d.Init()         // reset my being valueable, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range val {
		d = d.addM(v) // fullfill the promise
	}
}

func (d *StringMap) SetS(val ...[]string) {
	d.Lock()         // protect me, and ...
	d.Init()         // reset my being valueable, and ...
	defer d.Unlock() // release me, let me go ...
	for _, vals := range val {
		for _, v := range vals { // same as Add()
			d = d.add(v) // fullfill the promise
		}
	}
}
