// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap_test

import (
	"testing"

	"pannewitz.com/container/stringmap"
)

func TestSimple(t *testing.T) {

}

func ExampleStringMap() {
	var sms *stringmap.StringMap = stringmap.New("<root>")
	sms.PrintTree("1 >>")
	sms.Add("foo", "bar")
	sms.PrintTree("1 >>")
}
