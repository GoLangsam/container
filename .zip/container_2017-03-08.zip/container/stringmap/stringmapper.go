// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

import (
	"pannewitz.com/container/lsm"
	"pannewitz.com/container/tag"
)

/* TODO
print.go
doc.go
*/

type StringMapper interface {
	stringFriendly      // see below
	tag.Friendly        // via "pannewitz.com/container/tag"
	lsm.Friendly        // via "pannewitz.com/container/lsm"
	userFriendly        // extend.go: AddMap AddStrings AddStringS
	childrenFriendly    // children.go
	navigatorFriendly   // navigate.go: Up Root Path DownS
	privacyFriendly     // content.go
	printerFriendly     // print.go: PrintTree
	concurrencyFriendly // sync.go
	goFriendly
	//	ChildrenS() []StringMapper
}

type stringFriendly interface {
	setableFriendly    // set.go: Set/replace Content: Set SetS SetM
	extendableFriendly // add.go: Add/overwrite Content: Add AddS AddM
	removeFriendly     // del.go: Delete/remove vals from Content
}

var _ stringFriendly = New("Interface satisfied?")

type goFriendly interface {
	//	Sort([]StringMapper)
}

var _ goFriendly = New("Interface satisfied?")
