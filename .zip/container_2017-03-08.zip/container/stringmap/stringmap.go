// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

import (
	//	"fmt"
	//	"io/ioutil"
	//	"path/filepath"

	"sync"

	"pannewitz.com/container/lsm"
	"pannewitz.com/container/tag"
)

var _ StringMapper = New("Interface satisfied?")

type StringMap struct {
	*tag.TagAny                       // key
	*lsm.LazyStringerMap              // value(s)
	p                    StringMapper // parent: Up(), Root(), Path(), DownS()
	sync.Mutex                        // concurency included
}

// New returns what You need in order to keep a hand on me :-)
func New(key string) *StringMap {
	return &StringMap{
		tag.New(key),     // init key
		lsm.New(),        // init val
		nil,              // no parent
		*new(sync.Mutex), // mutex
	}
}
