// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type concurrencyFriendly interface {
	Lock()   // via sync.Mutex
	Unlock() // via sync.Mutex
}

var _ concurrencyFriendly = New("Interface satisfied? :-)")
