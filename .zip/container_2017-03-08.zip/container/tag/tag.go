// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package tag
package tag

import (
	"fmt"
	"sync"
)

// I love to be friendly - thus: I give You a simple API!
//  Create me with New(name) or Tag(name, stuff),
//  or with Named(fmt.Stringer), who names himself.
// Note: this interface is exposed for godoc - only ;-)
type Friendly interface {
	UserFriendly // use.go
	PathFriendly // path.go
}

var _ Friendly = New("Interface satisfied? :-)")

type TagAny struct {
	t string      // my tag text
	v interface{} // my value
	l sync.Mutex  // my private mutex
}

// New returns a new (empty) Tag
func New(tag string) *TagAny {
	t := new(TagAny)
	t.t = tag
	// t.v intentionally not set
	return t
}

// Tag returns a new Tag, initially set to val
func Tag(tag string, val interface{}) *TagAny {
	t := new(TagAny)
	t.t = tag
	t.v = val
	return t
}

// Named returns a new Tag, initially set to val and named as per val's String() method
func Named(val fmt.Stringer) *TagAny {
	t := new(TagAny)
	t.t = val.String()
	t.v = val
	return t
}
