﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package svp implements StringValuePair - named constants
//  Note: Being immutable implies concurrency saftey.
package svp // StringValuePair

import (
	"fmt"

	"pannewitz.com/do/ssr"	// string Stringer
)

// Note: this interface is exposed for godoc - only ;-)
//
// I love to be friendly - thus: I give You a simple API!
//  Create me with Svp(name, stuff), or Set(name, stuff string),
//  or New(stuff) with an fmt.Stringer, so stuff names himself.
//
type Friendly interface {
	UserFriendly    // use.go
	ConcurrencySafe // sync.go
	InfoFriendly // valuetype.go
	DeepInfoFriendly // leaftype.go
}

var _ Friendly = Svp("Interface satisfied? :-)", empty)

var empty interface{}

type StringValuePair struct {
	k string      // my key text
	v interface{} // my value
}

// New returns a new StringValuePair, named by the String() of val
func New(val fmt.Stringer) StringValuePair {
	return StringValuePair{val.String(), val}
}

// Set returns a new StringValuePair, named key, containg val
func Set(key, val string) StringValuePair {
	return StringValuePair{key, ssr.Stringer(val)}
}

// Svp returns a new StringValuePair
func Svp(key string, val interface{}) StringValuePair {
	return StringValuePair{key, val}
}
