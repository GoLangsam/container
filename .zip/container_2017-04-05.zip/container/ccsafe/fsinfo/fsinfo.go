﻿// package fsinfo represents an os.FileInfo associated to an FsPath and thus includes some 'reality check'.
package fsinfo

import (
	"os"            // os.SameFile
	"path/filepath" // filepath.Glob for Glob

	"container/ccsafe/fspath"
)

type FsInfo struct {
	*fspath.FsPath      // file system path - inherits many methods
	os.FileInfo         // file info
	exists         bool // true, if verified to exist on disk
}

// New returns a fresh FsInfo.
func New(path string) *FsInfo {
	fi, _ := Try(path)
	return fi
}

// Try returns a fresh FsInfo, and the error received from os.Stat() (if any)
func Try(path string) (*FsInfo, error) {
	fi, err := TryFsPath(fspath.New(path))
	return fi, err
}

// Try returns a fresh FsInfo, and the error received from os.Stat() (if any)
func TryFsPath(fp *fspath.FsPath) (*FsInfo, error) {
	if finfo, err := fp.Stat(); err == nil {
		return &FsInfo{fp, finfo, true}, nil
	} else {
		return &FsInfo{fp, finfo, false}, err
	}
}

// newExists returns a new OsPath representing an existing file system element (directory/file)
func newExists(name string, fi os.FileInfo) *FsInfo {
	fp := fspath.New(name)
	return &FsInfo{fp, fi, true}
}

// MatchDisk uses filepath.Glob and returns all entries matching the pattern,
// separated into directories and files, as slices of FsPath, and eventual
// encountered errors, which can only be ErrBadPattern or PathError
func MatchDisk(name string) (DirS, FilS []*FsInfo, err error) {
	errS := new(Errors)

	mS, err := filepath.Glob(name)
	if err != nil {
		errS.err(err)
	} else {
		for _, match := range mS {
			fi, err := os.Stat(match)
			if err == nil {
				fs := newExists(match, fi)
				if fs.IsDir() {
					DirS = append(DirS, fs)
				} else {
					FilS = append(FilS, fs)
				}
			} else {
				errS.err(err) // panic - can only be *PathError
			}
		}
	}
	return DirS, FilS, errS.got()
}

// Exists returns true, if OsPath is known to represent a real disk element
// which already exists on disk
func (fi *FsInfo) Exists() bool {
	return (fi.exists)
}

// SameFile reports whether fd and oi describe the same file.
// For example, on Unix this means that the device and inode fields
// of the two underlying structures are identical;
// on other systems the decision may be based on the path names.
// SameFile only applies to results returned by os.Stat.
// SameFile returns false in other cases.
func (fi *FsInfo) SameFile(oi os.FileInfo) bool {
	return os.SameFile(fi, oi)
}

// InfoEquals returns true, if all FileInfo data is same
func (fi *FsInfo) InfoEquals(oi os.FileInfo) bool {
	return (fi.Name() == oi.Name() &&
		fi.Size() == oi.Size() &&
		fi.Mode() == oi.Mode() &&
		fi.IsDir() == oi.IsDir() &&
		fi.ModTime() == oi.ModTime() &&
		fi.Sys() == oi.Sys())
}

type FsInfoS []*FsInfo

// AllDirs returns true only if for all elements IsDir is true
func (fiS FsInfoS) AllDirs() bool {
	for _, fi := range fiS {
		if !fi.IsDir() {
			return false
		}
	}
	return true
}
