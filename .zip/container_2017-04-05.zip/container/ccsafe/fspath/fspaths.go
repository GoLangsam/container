﻿package fspath

import (
	"os"
)

type FsPathS []*FsPath

// Validate returns any errors encountered when validating it's elements
func (fpS FsPathS) Validate() error {
	er := new(Errors)
	var err error
	for _, fp := range fpS {
		_, err = os.Stat(fp.fspath)
		er.err(err)
	}
	return er.got()
}

// Accessible returns any errors encountered when accessing it's elements
func (fpS FsPathS) Accessible() error {
	er := new(Errors)
	for _, fp := range fpS {
		er.err(fp.Accessible())
	}
	return er.got()
}
