// package fsdata represents an FsInfo and it's file data (originally associated to an FsPath)
package fsdata

import (
	"container/ccsafe/fsinfo"
)

type FsData struct {
	*fsinfo.FsInfo
	data string
}

func New(fi *fsinfo.FsInfo) *FsData {
	if fd, err := Try(fi); err != nil {
		panic("newFsData: ReadFile returned:" + err.Error())
	} else {
		return fd
	}
}

func Try(fi *fsinfo.FsInfo) (*FsData, error) {
	fd := &FsData{fi, ""}
	if fd.IsDir() {
		return fd, nil
	}
	var err error
	fd.data, err = fd.ReadFile()
	return fd, err
}

func (fd *FsData) Data() string {
	return fd.data
}
