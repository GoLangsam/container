// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"errors"
	"io"
	"sync"

	"container/ccsafe/lsm"
	"container/ccsafe/tag/ami"

	"do/ami"
)

type Dot struct {
	*tag.TagAny                        // key - a Key Value Pair
	*lsm.LazyStringerMap               // value(s) - an 'Anything' StringMap
	p                    *Dot          // parent: Up(), Root(), Path(), DownS()
	home                 *Dot          // home - never changes TODO: support!
	output               io.Writer     // for errors etc - nil means stderr; use out() accessor
	l                    *sync.RWMutex // private lock - concurency included!
}

// New returns what You need in order to keep a hand on me :-)
func New(key string) *Dot {
	dot := &Dot{
		tag.New(key),      // init key
		lsm.New(),         // init val
		nil,               // no parent
		nil,               // no home
		nil,               // no output - nil means stderr
		new(sync.RWMutex), // mutex
	}
	dot.home = dot // home - never changes
	return dot
}

type GoFriendly interface {
	// helper for templates:
	A(vals ...string) string // Add values, and return an empty string
	G(key string) *Dot       // Go into key
	KV(key, val string) *Dot // Assign a Key Value Pair
	// helper for "do/dot"
	UnlockedGet(key string) (interface{}, bool)
	UnlockedAdd(key string, val ...string) (interface{}, bool)
}

var _ GoFriendly = New("Interface satisfied?")

// A is a helper method for templates - it adds, and returns an empty string
func (d *Dot) A(vals ...string) string {
	d.l.Lock()         // protect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	for _, v := range vals {
		d = d.add(v) // fullfill the promise
	}
	return ""

}

// G is a helper method for templates - it Get's the (eventually new!) child (key)
// change name to Dot? Dot to Dots?
func (d *Dot) G(key string) *Dot {
	d.l.Lock()         // protect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	c := d.getChild(key)
	return c
}

// KV is a helper method for templates
func (d *Dot) KV(key, val string) *Dot {
	d.l.Lock()         // protect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	c := d.getChild(key)
	c.Tag(val)
	return d
}

/*
Locking - handling with "do/dot"
All calls into "do/dot" have d.l.Lock()
All callbacks into Dot used (via interface "do/dot.Dot")
are named "UnlockedXyz" and assume d.Lock is held
*/

// UnlockedGet is a helper method  - it returns the (eventually new!) child (key)
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *Dot) UnlockedGet(key string) (interface{}, bool) {
	//	d.l.Lock()         // protect me, and ...
	//	defer d.l.Unlock() // release me, let me go ...
	c := d.getChild(key)
	return c, true // bool avoids usage from templates!
}

// UnlockedAdd adds key to d, and adds variadic strings below key, and returns child "key"
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *Dot) UnlockedAdd(key string, val ...string) (interface{}, bool) {
	//	d.l.Lock()             // protect me, and ...
	//	defer d.l.Unlock()     // release me, let me go ...
	c := d.getChild(key)
	c.l.Lock()         // protect it, and ...
	defer c.l.Unlock() // release it, let it go ...
	c.add(val...)      // fullfill the promise
	return c, true     // bool avoids usage from templates!
}

func ToDot(v interface{}) (*Dot, error) {
	switch v := v.(type) {
	case *Dot:
		return v, nil
	default:
		return nil, errors.New("Expected 'Dot' - got '" + ami.TypeName(v) + "'!")
	}
}

// Friendly shows the composition as interface
type Friendly interface {
	tag.Friendly      // via "container/.../tag/..."
	lsm.Friendly      // via "container/.../lsm"
	StringFriendly    // dot.go: Set..., Assign..., Delete...
	ChildFriendly     // children.go: lookupDot getChild
	NavigatorFriendly // navigate.go: Up Root Path DownS
	PrinterFriendly   // print.go: PrintTree
	ErrorFriendly     // => dot!	error.go
	OutputFriendly    // output.go
	GoFriendly        // dot.go
}

var _ Friendly = New("Interface satisfied?")

/* TODO
doc.go
*/

type StringFriendly interface {
	/*
		SetableFriendly // set.go: Set/replace Content: Set SetS SetM
		AssignFriendly  // assign.go: Add/overwrite Content: Assignss AssignSs AssignMs
		UserFriendly    // add.go: AddMap AddStrings AddStringS
		DeleteFriendly  // delete.go: Delete/remove vals from Content: Deletes, DeleteS, DeleteM
		PrivacyFriendly // content.go: add addM
	*/
}

var _ StringFriendly = New("Interface satisfied?")
