// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

type concurrencyFriendly interface {
	LockVal()   // Lock, and invalidate val
	LockNew()   // Lock & invalidate val, and (re)initialise val
	UnlockVal() // release me, let me go ...
}

var _ concurrencyFriendly = New() // Interface satisfied? :-)

// Lock & invalidate val, and (re)initialise val
func (d *LazyStringMapper) LockNew() {
	d.LockVal() // protect me, and destroy my being valueable
	d.init()    // restore me as being valueable (just: empty)
}

// Lock, and invalidate val
func (d *LazyStringMapper) LockVal() {
	d.l.Lock()          // protect me
	d.lazyInit()        // make sure I'm not nil
	d.m, d.s = nil, nil // destroy my being valueable
}

// Unlock val
func (d *LazyStringMapper) UnlockVal() {
	d.l.Unlock() // release me, let me go ...
}
