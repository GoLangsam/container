// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"sort"
)

// helper to transform a map of strings into a sorted slice of strings
func sortM(m map[string]string) []string {
	slice := make([]string, 0, len(m))
	for key, _ := range m {
		slice = append(slice, key)
	}
	sort.Strings(slice)
	return slice
}
