// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

type accessFriendly interface {
	M() map[string]string // return Content as map
	S() []string          // return Content as sorted slice
}

var _ accessFriendly = New() // Interface satisfied? :-)

// M returns the content as map[string]string
// Thus: {{ .M."output".S }} acesses the main map for key="output"
// and returns its content as a slice
func (d *LazyStringMapper) M() map[string]string {
	d.l.Lock()         // protect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.lazyM()   // fullfill the promise
}

// S returns the content as sorted slice
// Thus: {{ range .S }} walks the slice of the root's node content
func (d *LazyStringMapper) S() []string {
	d.l.Lock()         // protect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.lazyS()   // fullfill the promise
}
