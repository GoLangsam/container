// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

import (
	"fmt"
)

const tab = `\t`

func (d *StringMap) PrintTree(prefix ...string) {
	var indent string
	for i, pre := range prefix {
		if i > 0 {
			indent = indent + tab
		}
		indent = indent + pre
	}
	printTree(indent, d)
}

func printTree(indent string, d StringMapper) {
	if d == nil {
		return
	}
	fmt.Println(indent, d.String())
	for _, m := range d.DownS() {
		printTree(indent+tab, m)
	}
}
