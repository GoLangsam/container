// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type privacyFriendly interface {
	set(vals ...string)                       // initialise content, and add val as (new) children
	add(vals ...string) *StringMap            // add val as children to current content
	addM(val ...map[string]string) *StringMap // add content named val: to any child named as key add content named as val[key]
}

var _ privacyFriendly = New("Interface satisfied? :-)")

// Value modifiers - internal - to be used with locked d

// (re)initilise content and populate with vals (if any)
func (d *StringMap) set(vals ...string) {
	d.Init()
	d.add(vals...)
}

// add content named val
func (d *StringMap) add(vals ...string) *StringMap {
	for _, k := range vals {
		_ = d.getChild(k)
	}
	return d
}

// addM adds children named as key and adds content named as val[key]
//
// Note: as many childs may be added, the common parent (which is me) is returned
func (d *StringMap) addM(val ...map[string]string) *StringMap {
	for _, maps := range val {
		for k, v := range maps {
			c := d.getChild(k)
			_ = c.getChild(v)
		}
	}
	return d
}
