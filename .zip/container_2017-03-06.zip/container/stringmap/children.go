// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type childrenFriendly interface {
	get(key string) (*StringMap, bool)
	getChild(key string) *StringMap
}

var _ childrenFriendly = New("Interface satisfied? :-)")

// get is internal accessor
func (d *StringMap) get(key string) (*StringMap, bool) {
	var c *StringMap

	c.Lock()         // protect it, and ...
	defer c.Unlock() // release it, let it go ...

	if x, ok := d.Get(key); !ok || c == nil {
		return nil, false
	} else if c, ok = x.(*StringMap); !ok {
		return nil, false // panic("Did not get type StringMap from lsm")
	} else {
		return c, true
	}
}

// getChild returns the child named by key, and panics if wrong type was found
//
// Note:
// - the child is handled concurrency safe
// - a new child is created and linked, if need
// - if d:Get(key) returns wrong type, getChild panics
func (d *StringMap) getChild(key string) *StringMap {
	var c *StringMap

	c.Lock()         // protect it, and ...
	defer c.Unlock() // release it, let it go ...

	if x, ok := d.Get(key); !ok || c == nil {
		c = New(key) // new child
		c.p = d      // set me as it's parent
	} else if c, ok = x.(*StringMap); !ok {
		panic("Did not get type StringMap from lsm")
	}

	if c.p != d { // sanity check
		panic("Ups: I am *not* parent of child?!?") // TODO: better formatting
	}
	return c
}
