﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stringmap

type concurrencyFriendly interface {
	Lock()      // via sync.Mutex
	Unlock()    // via sync.Mutex
	// LockNew()   // via *lsm.LazyStringMapper
	// LockVal()   // via *lsm.LazyStringMapper
	// UnlockVal() // via *lsm.LazyStringMapper
	lockVal()   // Lock me and my val, and invalidate val
	lockNew()   // lockVal & invalidate val, and (re)initialise val
	unlockVal() // release my value and myself
}

var _ concurrencyFriendly = New("Interface satisfied? :-)")

// Lock & invalidate val, and (re)initialise val
func (d *StringMap) lockNew() {
	d.Lock()    // protect me, and ...
	d.LockVal() // destroy my being valueable
	d.Init()    // restore me as being valueable (just: empty)
}

// Lock, and invalidate val
func (d *StringMap) lockVal() {
	d.Lock()    // protect me, and ...
	d.LockVal() // destroy my being valueable
}

func (d *StringMap) unlockVal() {
	d.UnlockVal() // release my value, and ...
	d.Unlock()    // release me, let me go ...
}
