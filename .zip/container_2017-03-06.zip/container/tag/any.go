// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package tag
package tag

import (
	"sync"
)

type TagFriendly interface {
	String() string      // fmt.Stringer
	Tag(val interface{}) // Set/replace AnyValue/Payload
	T() string           // Return the tag string
	V() interface{}      // Return AnyValue/Payload
}

var _ TagFriendly = New("Interface satisfied? :-)")

type TagAny struct {
	t string
	v interface{}
	l sync.Mutex // my private mutex
}

func New(tag string) *TagAny {
	t := new(TagAny)
	t.t = tag
	return t
}

// implement fmt.Stringer
func (d *TagAny) String() string {
	d.l.Lock()         // proctect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.t
}

// Tag attaches me to my AnyValue/Payload
func (d *TagAny) Tag(val interface{}) {
	d.l.Lock()         // proctect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	d.v = val
}

// T returns the tag string
func (d *TagAny) T() string {
	d.l.Lock()         // proctect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.t
}

// V returns my AnyValue/Payload
func (d *TagAny) V() interface{} {
	d.l.Lock()         // proctect me, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.v
}
