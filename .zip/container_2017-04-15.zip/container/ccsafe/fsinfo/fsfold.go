package fsinfo

// FsFold represents a folder / directory of the file system.
// It may indicate to be (or have been) recursed into.
//  Note: FsFold is immutable, and as such safe for concurrent use.
type FsFold struct {
	fsInfo
	recurse *bool
}

// ForceFold returns a fresh FsFold given a pathname.
func ForceFold(name string) *FsFold {
	return newFold(name)
}

// newFold returns a fresh unqualified FsFold
func newFold(name string) *FsFold {
	return &FsFold{*newInfo(name), nil}
}

// AsFold returns a fresh FsFold for the given FsInfo,
// or panics, if the FsInfo does not represent a Dir.
func (f *fsInfo) AsFold() *FsFold {
	if fd, ok := f.TryFold(); !ok {
		panic("AsFold: " + f.String() + " seems not to be a directory!")
	} else {
		return fd
	}
}

// TryFold returns a fresh FsFold, or false if not fi.IsDir().
func (f *fsInfo) TryFold() (*FsFold, bool) {
	if !f.IsDir() {
		return nil, false
	} else {
		return &FsFold{*f, nil}, true
	}
}

type FsFoldS []*FsFold

// MatchFolds
// matches pathName against the Disk (via MatchDisk/Glob) and then returns only those
// folders/directories
// the base name of which matches any of the given patternlists.
// Any eventual filesystem errors are ignored and skipped over.
func MatchFolds(pathName string, patternlists ...string) (dirS FsFoldS) {
	dS, fS, _ := MatchDisk(pathName)
	_ = fS // Files are ignored here
	for _, d := range dS {
		if ok, _ := d.BaseMatchesList(patternlists...); ok {
			dirS = append(dirS, d)
		}
	}
	/*
		//  Note: any directory matching the patternlists is also recursed into - breadth first.
		//  BUG: infinite loops due to symlink-cycles in the file system are not prevented.
			for _, d := range dS {
				if ok, _ := d.PathMatchesList(patternlists...); ok {
					dirS = append(dirS, MatchFolds(d.String(), patternlists...)...)
				}
			}
	*/
	return dirS
}

// AsNotDown returns a fresh FsFold representing a file system directory/file not to be recursed into.
func (f *fsInfo) AsNotDown() *FsFold {
	var recurse bool = false
	return &FsFold{*f, &recurse}
}

// NotDown returns a fresh FsFold given a pathname, which also indicates not to be recursed into.
func NotDown(name string) *FsFold {
	return newInfo(name).AsNotDown()
}

// AsRecurse returns a fresh FsFold representing a file system directory/file to be recursed into.
func (f *fsInfo) AsRecurse() *FsFold {
	var recurse bool = true
	return &FsFold{*f, &recurse}
}

// Recurse returns a fresh FsFold given a pathname, which also indicates to be recursed.
func Recurse(name string) *FsFold {
	return newInfo(name).AsRecurse()
}

// Recurse returns true if this folder indicates to be recursed into
func (f *FsFold) Recurse() bool {
	if f.recurse == nil {
		return false
	} else {
		return *f.recurse
	}
}

// HasRecurse returns true if this folder has a recurse indicator
func (f *FsFold) HasRecurse() bool {
	if f.recurse == nil {
		return false
	} else {
		return true
	}
}

// TabString returns the Name and the Recurse flag as a Tab terminated string
func (f *FsFold) TabString() string {
	if f.Recurse() {
		return f.String() + "\t" + "Recurse=true" + "\t"
	} else {
		return f.String() + "\t"
	}
}

// FileS returns all files in f matching any of the patterns in the patternlists
func (f *FsFold) FileS(patternLists ...string) (FilS FsFileS) {
	return MatchFiles(f.JoinWith(MatchAny), patternLists...)
}
