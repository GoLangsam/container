package fsinfo

// FsData represents the data (as read upon it's creation) of a related FsFile
// and is intended to be used by higher packages such as FsCache.
//  Note: FsData is immutable, and as such safe for concurrent use.
type FsData struct {
	FsFile
	byteS []byte
}

// ForceData returns a fresh FsData having given name and data.
func ForceData(name string, data []byte) *FsData {
	return newData(name, data)
}

// newData returns a fresh FsData given a name and some data,
// based on a fresh FsFile.
func newData(name string, data []byte) *FsData {
	return &FsData{*newFile(name), data}
}

// AsData returns a fresh FsData for the given FsFile,
// or panics, if TryData returns an error.
func (f *FsFile) AsData() *FsData {
	if fd, ok := f.TryData(); !ok {
		panic("newFsData: ReadFile returned an error!")
	} else {
		return fd
	}
}

// TryData returns a fresh FsData for the given FsFile,
// or false (and empty byteS/data) iff ReadFile() returned an error.
func (f *FsFile) TryData() (*FsData, bool) {
	fd := &FsData{*f, []byte{}}
	data, err := fd.ReadFile()
	if err == nil {
		fd.byteS = data
		return fd, true
	} else {
		return fd, false
	}
}

// ByteS returns the cached data
func (f *FsData) ByteS() []byte {
	return f.byteS
}

// Data returns the cached data as string
func (f *FsData) Data() string {
	return string(f.byteS)
}

type FsDataS []*FsData
