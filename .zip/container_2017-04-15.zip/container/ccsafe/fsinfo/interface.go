package fsinfo

import (
	"os"
)

// PathFriendly summarises many methods inherited from internal type fsPath
// in related groups / sub interfaces
//  Note: this interface is exposed not only for godoc ;-)
type PathFriendly interface {
	FilePathFriendly
	MatchFriendly
	OsFileInfoFriendly
	OsFileFriendly

	MkDir() error
	Accessible() error
	AsBase() *FsBase
}

type FilePathFriendly interface {
	String() string

	Base() string
	Ext() string
	BaseLessExt() string

	JoinWith(elem ...string) string
}

type MatchFriendly interface {
	DiskFriendly
	Match(pattern string) (matched bool, err error)
	PathMatchesList(list ...string) (matched bool, err error)
	PathMatches(patterns ...string) (matched bool, err error)
	BaseMatchesList(list ...string) (matched bool, err error)
	BaseMatches(patterns ...string) (matched bool, err error)
}

type DiskFriendly interface {
	Glob() (matches []string, err error)
}

type OsFileInfoFriendly interface {
	// obtain os.FileInfo
	Stat() (os.FileInfo, error)
	ReadDir() ([]os.FileInfo, error)
}

type OsFileFriendly interface {
	Create() (*os.File, error)
	Open() (*os.File, error)

	// File Read/Write
	ReadFile() ([]byte, error)
	WriteFile(byteS []byte) error
}

// BaseFriendly summarises methods of type FsBase
//  Note: this interface is exposed not only for godoc ;-)
type BaseFriendly interface {
	PathFriendly
}

// InfoFriendly summarises many methods inherited from internal type fsInfo
// in related groups / sub interfaces
//  Note: this interface is exposed not only for godoc ;-)
type InfoFriendly interface {
	PathFriendly
	AsFile() *FsFile
	TryFile() (*FsFile, bool)
	AsFold() *FsFold
	TryFold() (*FsFold, bool)
	AsNotDown() *FsFold
	AsRecurse() *FsFold

	Exists() bool
	SameFile(oi os.FileInfo) bool
	InfoEquals(oi os.FileInfo) bool

	MatchDisk() (dirS FsFoldS, filS FsFileS, err error)

	ReadDirS() (entrieS FsInfoS, err error)

	SubDirS() (DirS []*FsFold)
}

// FileFriendly summarises methods of type FsFile
//  Note: this interface is exposed not only for godoc ;-)
type FileFriendly interface {
	InfoFriendly
}

// FoldFriendly summarises methods of type FsFold
//  Note: this interface is exposed not only for godoc ;-)
type FoldFriendly interface {
	InfoFriendly

	// AsNotDown() *FsFold

	Recurse() bool
	HasRecurse() bool

	TabString() string

	FileS(patternLists ...string) (FilS FsFileS)
}

// DataFriendly summarises methods of type FsData
//  Note: this interface is exposed not only for godoc ;-)
type DataFriendly interface {
	InfoFriendly

	ByteS() []byte
	Data() string
}

var _ PathFriendly = newPath("Interface statisifed") // FsInfo

var _ InfoFriendly = newInfo("Interface statisifed") // FsInfo

var _ FileFriendly = newFile("Interface statisifed") // FsFile
//r _ FileFriendly = newInfo("Interface statisifed").AsFile() // FsFile - TODO:panics

var _ FoldFriendly = newFold("Interface statisifed") // FsFold
//r _ FoldFriendly = newInfo("Interface statisifed").AsFold() // FsFold - TODO:panics

var _ BaseFriendly = newBase("Interface statisifed")          // FsBase
var _ BaseFriendly = newInfo("Interface statisifed").AsBase() // FsBase

var _ DataFriendly = newData("Interface statisifed", []byte("Are You Sure?")) // FsData
//r _ DataFriendly = newFile("Interface statisifed").AsData() // FsData - panics
