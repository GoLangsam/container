package fsinfo

import (
	"os"            // os.SameFile
	"path/filepath" // filepath.Glob for Glob
)

// FsInfo represents a file system object including it's os.Info as found upon creation.
//  Note: FsInfo is immutable, and as such safe for concurrent use.
type fsInfo struct {
	fsPath           // file system path - inherits many methods
	os.FileInfo      // file info
	exists      bool // true, if verified to exist on disk
}

// newInfo returns a fresh FsInfo.
func newInfo(path string) *fsInfo {
	fi, _ := Try(path)
	return fi
}

// Try returns a fresh FsInfo, and the error received from os.Stat() (if any)
func Try(path string) (*fsInfo, error) {
	fi, err := TryFsPath(newPath(path))
	return fi, err
}

// Try returns a fresh FsInfo, and the error received from os.Stat() (if any)
func TryFsPath(fp *fsPath) (*fsInfo, error) {
	if finfo, err := fp.Stat(); err == nil {
		return &fsInfo{*fp, finfo, true}, nil
	} else {
		return &fsInfo{*fp, finfo, false}, err
	}
}

// newExists returns a new OsPath representing an existing file system element (directory/file)
func newExists(name string, fi os.FileInfo) *fsInfo {
	fp := newPath(name)
	return &fsInfo{*fp, fi, true}
}

// SubDirS returns fi and all it's (recursed) subdirectories,
// the directory tree rooted at fi, so to say.
func (f *fsInfo) SubDirS() (DirS []*FsFold) {
	if !f.IsDir() {
		return DirS
	}
	dir := f.AsRecurse()
	DirS = append(DirS, dir)
	if dirInfoS, err := f.ReadDir(); err == nil {
		for _, dirInfo := range dirInfoS {
			if dirInfo.IsDir() {
				dir := Recurse(filepath.Join(f.String(), dirInfo.Name()))
				DirS = append(DirS, dir.SubDirS()...)
			}
		}
	}
	return DirS
}

// MatchDisk
func (f *fsInfo) MatchDisk() (dirS FsFoldS, filS FsFileS, err error) {
	return MatchDisk(f.String())

}

// ReadDirS reads the directory named by OsPath.Path() and returns a FsInfo slice
// of directory entries sorted by filename.
func (f *fsInfo) ReadDirS() (entrieS FsInfoS, err error) {
	if finfoS, err := f.ReadDir(); err == nil {
		for _, finfo := range finfoS {
			entrieS = append(entrieS, newExists(filepath.Join(f.String(), finfo.Name()), f))
		}
	}
	return entrieS, err
}

// Exists returns true, if OsPath is known to represent a real disk element
// which already exists on disk
func (f *fsInfo) Exists() bool {
	return (f.exists)
}

// SameFile reports whether f and oi describe the same file.
// For example, on Unix this means that the device and inode fields
// of the two underlying structures are identical;
// on other systems the decision may be based on the path names.
// SameFile only applies to results returned by os.Stat.
// SameFile returns false in other cases.
func (f *fsInfo) SameFile(oi os.FileInfo) bool {
	return os.SameFile(f, oi)
}

// InfoEquals returns true, if all FileInfo data is same.
func (f *fsInfo) InfoEquals(oi os.FileInfo) bool {
	return (f.Name() == oi.Name() &&
		f.Size() == oi.Size() &&
		f.Mode() == oi.Mode() &&
		f.IsDir() == oi.IsDir() &&
		f.ModTime() == oi.ModTime() &&
		f.Sys() == oi.Sys())
}

type FsInfoS []*fsInfo

// AllDirs returns true if and only if for all elements IsDir is true.
func (fiS FsInfoS) AllDirs() bool {
	for _, fi := range fiS {
		if !fi.IsDir() {
			return false
		}
	}
	return true
}
