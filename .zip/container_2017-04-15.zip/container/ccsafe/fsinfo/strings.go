package fsinfo

import (
	"path/filepath"
	"strings"
)

// Base is a convenience for filepath.Base()
func Base(name string) string {
	return filepath.Base(name)
}

// Ext is a convenience for filepath.Ext()
func Ext(name string) string {
	return filepath.Ext(name)
}

// BaseLessExt: name.Base() less name.Ext()
func BaseLessExt(name string) string {
	return strings.TrimSuffix(filepath.Base(name), filepath.Ext(name))
}

// Match reports whether name matches any of the shell file name patter lists.
//  Note: any name matches an empty patternlists and any empty pattern,
//  but not not an empty patternlist.
func Match(name string, patternlists ...string) (matched bool, err error) {
	var match bool
	for _, patternlist := range patternlists {
		for _, pattern := range filepath.SplitList(patternlist) {
			if len(pattern) > 0 {
				if ok, err := filepath.Match(pattern, name); err != nil {
					// println("Name:", name, "ERR", pattern)
					return false, err
				} else if ok {
					// println("Name:", name, "!!!", pattern)
					match = true
				} else {
					// println("Name:", name, "???", pattern)
				}
			} else {
				// println("Name:", name, "!!! - No pattern")
				match = true
			}
		}
	}
	if len(patternlists) > 0 {
		if match {
			// println("Name:", name, "!!!Match")
		} else {
			// println("Name:", name, "no Match")
		}
		return match, nil

	} else {
		// println("Name:", name, "no patternlists")
		return true, nil
	}
}
