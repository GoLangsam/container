package fsinfo

import (
	"fmt"
)

func FsInfoSPrintFunc(prefix string) func(fp fsInfo) fsInfo {
	return func(fp fsInfo) fsInfo {
		fmt.Println(prefix, fp.String())
		return fp
	}
}

func PipeFsInfoFork(inp <-chan fsInfo) (out1, out2 <-chan fsInfo) {
	cha1 := make(chan fsInfo)
	cha2 := make(chan fsInfo)
	go func() {
		defer close(cha1)
		defer close(cha2)
		for i := range inp {
			cha1 <- i
			cha2 <- i
		}
	}()
	return cha1, cha2
}

func PipeFsInfoGlob(
	inp <-chan fsInfo,
	dirS chan<- FsFold,
	filS chan<- FsFile) (
	out <-chan struct{}) {
	cha := make(chan struct{})
	go func() {
		defer close(cha)
		for name := range inp {
			dS, fS, _ := MatchDisk(name.JoinWith("*.tmpl")) // TODO:
			for _, d := range dS {
				dirS <- *d
			}
			for _, f := range fS {
				filS <- *f
			}
		}
		cha <- struct{}{}
	}()
	return cha
}

// PipeFsInfoS returns a channel which will receice a slice of all elements
// received on inp channel, and will be closed thereafter.
// Thus, it behaves similar to a Done channel, just sending a full slice once,
// not just an (otherwise empty) event.
func PipeFsInfoS(inp <-chan fsInfo) (out <-chan []fsInfo) {
	cha := make(chan []fsInfo)
	go func(inp <-chan fsInfo, out chan<- []fsInfo) {
		defer close(out)
		FsInfoS := []fsInfo{}
		for i := range inp {
			FsInfoS = append(FsInfoS, i)
		}
		out <- FsInfoS
	}(inp, cha)
	return cha
}
