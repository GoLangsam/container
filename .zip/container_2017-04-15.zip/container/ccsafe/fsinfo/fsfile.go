package fsinfo

// FsFile represents a file of the file system.
//  Note: FsFile is immutable, and as such safe for concurrent use.
type FsFile struct {
	fsInfo
}

// ForceFile returns a fresh FsFile having given name.
func ForceFile(name string) *FsFile {
	return newFile(name)
}

// newFile returns a fresh FsFile having given name.
func newFile(name string) *FsFile {
	return &FsFile{*newInfo(name)}
}

// AsFile returns a fresh FsFile for the given FsInfo,
// or panics, if the FsInfo represents a Dir.
func (f *fsInfo) AsFile() *FsFile {
	if fd, ok := f.TryFile(); !ok {
		panic("AsFile: " + f.String() + " seems to be a directory!")
	} else {
		return fd
	}
}

// TryFile returns a fresh FsFile, or false if fi.IsDir().
func (f *fsInfo) TryFile() (*FsFile, bool) {
	if f.IsDir() {
		return nil, false
	} else {
		return &FsFile{*f}, true
	}
}

type FsFileS []*FsFile

// MatchFiles
// matches pathName against the Disk (via MatchDisk/Glob) and then returns only those
// files
// the base name of which matches any of the given patternlists.
// Any eventual filesystem errors are ignored and skipped over.
func MatchFiles(pathName string, patternlists ...string) (filS FsFileS) {
	dS, fS, _ := MatchDisk(pathName)
	_ = dS // Folds are ignored here
	for _, f := range fS {
		if ok, _ := f.BaseMatchesList(patternlists...); ok {
			filS = append(filS, f)
		}
	}
	return filS
}
