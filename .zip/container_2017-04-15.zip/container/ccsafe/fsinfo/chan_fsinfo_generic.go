﻿// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// DO NOT EDIT.
// Generate with: go run gen.go

package fsinfo

// MakeFsInfoChan returns a new open channel
// (simply a 'chan fsInfo' that is).
//
// Note: No 'FsInfo-producer' is launched here yet! (as is in all the other functions).
//
// This is useful to easily create corresponding variables such as
//
//	var myFsInfoPipelineStartsHere := MakeFsInfoChan()
//	// ... lot's of code to design and build Your favourite "myFsInfoWorkflowPipeline"
//	// ...
//	// ... *before* You start pouring data into it, e.g. simply via:
//	for drop := range water {
//		myFsInfoPipelineStartsHere <- drop
//	}
//	close(myFsInfoPipelineStartsHere)
//
// Hint: especially helpful, if Your piping library operates on some hidden (non-exported) type
// (or on a type imported from elsewhere - and You don't want/need or should(!) have to care.)
//
// Note: as always (except for PipeFsInfoBuffer) the channel is unbuffered.
//
func MakeFsInfoChan() (out chan fsInfo) {
	cha := make(chan fsInfo)
	return cha
}

// ChanFsInfo
func ChanFsInfo(inp ...*fsInfo) (out <-chan fsInfo) {
	cha := make(chan fsInfo)
	go func(out chan<- fsInfo, inp ...*fsInfo) {
		defer close(out)
		for _, i := range inp {
			out <- *i
		}
	}(cha, inp...)
	return cha
}

// ChanFsInfoSlice
func ChanFsInfoSlice(inp []fsInfo) (out <-chan fsInfo) {
	cha := make(chan fsInfo)
	go func(out chan<- fsInfo, inp []fsInfo) {
		defer close(out)
		for _, i := range inp {
			out <- i
		}
	}(cha, inp)
	return cha
}

// JoinFsInfo
func JoinFsInfo(out chan<- fsInfo, inp ...fsInfo) {
	// cha := make(chan fsInfo)	// no need
	go func(out chan<- fsInfo, inp ...fsInfo) {
		// defer close(out)	// no need
		for _, i := range inp {
			out <- i
		}
	}(out, inp...)
	// return cha	// no need
}

// JoinFsInfoSlice
func JoinFsInfoSlice(out chan<- fsInfo, inp []fsInfo) {
	// cha := make(chan fsInfo)	// no need
	go func(out chan<- fsInfo, inp []fsInfo) {
		// defer close(out)	// no need
		for _, i := range inp {
			out <- i
		}
	}(out, inp)
	// return cha	// no need
}

// JoinFsInfoChan
func JoinFsInfoChan(out chan<- fsInfo, inp <-chan fsInfo) {
	// cha := make(chan fsInfo)	// no need
	go func(out chan<- fsInfo, inp <-chan fsInfo) {
		// defer close(out)	// no need
		for i := range inp {
			out <- i
		}
	}(out, inp)
	// return cha	// no need
}

// DoneFsInfo
func DoneFsInfo(inp <-chan fsInfo) (out <-chan struct{}) {
	cha := make(chan struct{})
	go func(inp <-chan fsInfo, out chan<- struct{}) {
		defer close(out)
		for i := range inp {
			_ = i // Drain inp
		}
		out <- struct{}{}
	}(inp, cha)
	return cha
}

// DoneFsInfoFunc
func DoneFsInfoFunc(inp <-chan fsInfo, act func(a fsInfo)) (out <-chan struct{}) {
	cha := make(chan struct{})
	if act == nil {
		act = func(a fsInfo) { return }
	}
	go func(inp <-chan fsInfo, act func(a fsInfo), out chan<- struct{}) {
		defer close(out)
		for i := range inp {
			act(i) // Apply action
		}
		out <- struct{}{}
	}(inp, act, cha)
	return cha
}

// PipeFsInfoBuffer
func PipeFsInfoBuffer(inp <-chan fsInfo, cap int) (out <-chan fsInfo) {
	cha := make(chan fsInfo, cap)
	go func(inp <-chan fsInfo, out chan<- fsInfo) {
		defer close(out)
		for i := range inp {
			out <- i
		}
	}(inp, cha)
	return cha
}

// PipeFsInfoFunc
// Note: it 'could' be PipeFsInfoMap for functional people,
// but 'map' has a very different meaning in go lang.
func PipeFsInfoFunc(inp <-chan fsInfo, act func(a fsInfo) fsInfo) (out <-chan fsInfo) {
	cha := make(chan fsInfo)
	if act == nil {
		act = func(a fsInfo) fsInfo { return a }
	}
	go func(inp <-chan fsInfo, act func(a fsInfo) fsInfo, out chan<- fsInfo) {
		defer close(out)
		for i := range inp {
			out <- act(i)
		}
	}(inp, act, cha)
	return cha
}

// Vocab:
// Demand  request call claim order
// Supply  Provide

// Request - aka Get
// Provide - aka Put

//   FsInfoRequester
type FsInfoDemander interface {
	RequestFsInfo() fsInfo
}

//   FsInfoProvider
type FsInfoSupplier interface {
	ProvideFsInfo(fsInfo)
}

// A Channel of type FsInfo satisfies this:
type FsInfoChaneler interface {
	FsInfoDemander
	FsInfoSupplier
}

type DemandFsInfo struct { // demand channel
	dat chan fsInfo
	req chan struct{}
}

func NewDemandFsInfoChan() *DemandFsInfo {
	d := new(DemandFsInfo)
	d.dat = make(chan fsInfo)
	d.req = make(chan struct{})
	return d
}

func (out *DemandFsInfo) ProvideFsInfo(dat fsInfo) {
	<-out.req
	out.dat <- dat
}

func (inp *DemandFsInfo) RequestFsInfo() (dat fsInfo) {
	inp.req <- struct{}{}
	return <-inp.dat
}

type SupplyFsInfo struct { // supply channel
	dat chan fsInfo
	// req chan struct{}
}

func NewSupplyFsInfoChan() *SupplyFsInfo {
	d := new(SupplyFsInfo)
	d.dat = make(chan fsInfo)
	// d.req = make(chan struct{})
	return d
}

func (out *SupplyFsInfo) Provide(dat fsInfo) {
	// <-out.req
	out.dat <- dat
}

func (inp *SupplyFsInfo) Request() (dat fsInfo) {
	// inp.req <- struct{}{}
	return <-inp.dat
}
