package fsinfo

// FsBase represents a basename of the file system.
//  Note: FsBase is immutable, and as such safe for concurrent use.
type FsBase struct {
	fsPath
}

// ForceBase returns a fresh FsBase representing the Base(name) of the given a name.
func ForceBase(name string) *FsBase {
	return newBase(name)
}

// newBase returns a fresh FsBase representing the Base(name) of the given a name.
func newBase(name string) *FsBase {
	return &FsBase{*newPath(Base(name))}
}

// AsBase returns a fresh FsBase for the given FsInfo.
func (f *fsPath) AsBase() *FsBase {
	return newBase(f.Base())
}

// TryBase returns a fresh FsBase for the given path and
// false iff path is not identical to it's own Base(name).
func (f *fsPath) TryBase() (*FsBase, bool) {
	return f.AsBase(), (f.String() == f.Base())
}

type FsBaseS []*FsBase
