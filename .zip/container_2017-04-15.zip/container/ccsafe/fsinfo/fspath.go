package fsinfo

import (
	"io/ioutil"
	"os"
	"path/filepath" // filepath.SplitList for NewS, and filepath.Glob for Glob
)

// fsPath represents a file system path with os related functionalities
// and makes it's methods available to the derived types of this package.
//  Note: fsPath itself is intentionally not exported.
type fsPath struct {
	fspath string // file system path
}

// newPath returns a fresh fsPath representing some file system element (directory/file),
// regardless whether it exists, or not, or is even a pattern.
func newPath(path string) *fsPath {
	return &fsPath{path}
}

// String returns the pathtext repreented by fsPath
func (f *fsPath) String() string {
	return f.fspath
}

// NewS returns a non-empty slice of OsPath obtained via filepath.SplitList
func NewS(pathNames ...string) (pathS FsPathS) {
	/*
		for _, path := range dotpath.NewS(pathNames...) {
			pathS = append(pathS, OsPath{path})
		}
		return pathS
	*/
	if len(pathNames) < 1 {
		pathS = append(pathS, newPath(""))
	} else {
		for _, pathList := range pathNames {
			for _, pathName := range filepath.SplitList(pathList) {
				pathS = append(pathS, newPath(pathName))
			}
		}
	}
	return pathS
}

// Stat - returns the actual os.Stat() and the error received from os.Stat (of type *PathError)
//  Note: Stat does not refer to the FileInfo originally embedded into fsPath and thus may return
//  different FileInfo, if content of file system representetd by fsPath has changed.
func (f *fsPath) Stat() (os.FileInfo, error) {
	fi, err := os.Stat(f.fspath)
	return fi, err
}

// JoinWith joins f with any number of path elements into a single path,
// adding a Separator if necessary.
// Join calls Clean on the result; in particular, all empty strings are ignored.
// On Windows, the result is a UNC path if and only if the first path element is a UNC path.
func (f *fsPath) JoinWith(elem ...string) string {
	e := make([]string, 0, len(elem)+1)
	e = append(e, f.fspath)
	e = append(e, elem...)
	return filepath.Join(e...)
}

// Base returns the last element of path.
// Trailing path separators are removed before extracting the last element.
// If the path is empty, Base returns ".".
// If the path consists entirely of separators, Base returns a single separator.
func (f *fsPath) Base() string {
	return filepath.Base(f.fspath)
}

// Ext returns the file name extension used by path.
// The extension is the suffix beginning at the final dot in the final element of path;
// it is empty if there is no dot.
func (f *fsPath) Ext() string {
	return filepath.Ext(f.fspath)
}

// Match reports whether name matches the shell file name pattern.
func (f *fsPath) Match(pattern string) (matched bool, err error) {
	matched, err = filepath.Match(pattern, f.fspath)
	return matched, err
}

// Glob returns the names of all files matching the pattern (=PathText()),
// or nil if there is no matching entry(file/directory).
//  Note. The pattern may describe hierarchical names such as
//  /usr/*/bin/ed (assuming the Separator is '/').
//
// Glob ignores file system errors such as I/O errors reading directories.
// The only possible returned error is ErrBadPattern, when pattern is malformed.
//
//  Note: If fsPath does not exist, Glob may return matches, if fsPath represents a pattern.
//  If fsPath exists, Glob should return exactly one match: itself (unless Ospwd has changed).

func (f *fsPath) Glob() (matches []string, err error) {
	matches, err = filepath.Glob(f.fspath)
	return matches, err
}

// Accessible - returns nil, or the error received from os.Open (or Close)
func (f *fsPath) Accessible() error {
	file, err := os.Open(f.fspath)
	if err != nil {
		return err
	}
	return file.Close()
}

// MkDir uses os.MkdirAll to create a directory named by fsPath, along with any necessary parents,
// and returns nil, or else returns an error.
// The permission bits Perm are used for all created directories.
// If fsPath is already a directory, MkDir does nothing and returns nil.
func (f *fsPath) MkDir() error {
	return os.MkdirAll(f.fspath, Perm)
}

// Create creates the file named by OsPath.Path() with mode 0666 (before umask),
// truncating it if it already exists.
// If successful, methods on the returned File can be used for I/O;
// the associated file descriptor has mode O_RDWR.
// If there is an error, it will be of type *PathError.
//  Note: do not forget to defer file.Close()
func (f *fsPath) Create() (*os.File, error) {
	file, err := os.Create(f.fspath)
	return file, err
}

// Open opens the file named by OsPath.Path() for reading.
// If successful, methods on the returned file can be used for reading;
// the associated file descriptor has mode O_RDONLY.
// If there is an error, it will be of type *PathError.
//  Note: do not forget to defer file.Close()
func (f *fsPath) Open() (*os.File, error) {
	file, err := os.Open(f.fspath)
	return file, err
}

// ReadFile reads the file named by OsPath.Path() and returns the contents.
//  Note: A successful call returns err == nil, not err == EOF.
//  Because ReadFile reads the whole file, it does not treat an EOF from Read as an error to be reported.
//  Note: for convenience, the contents is returned as string, not as []byte.
func (f *fsPath) ReadFile() ([]byte, error) {
	byteS, err := ioutil.ReadFile(f.fspath)
	return byteS, err
}

// WriteFile writes data to a file named by fsPath.
// If the file does not exist, WriteFile creates it with permissions Perm;
// otherwise WriteFile truncates it before writing.
func (f *fsPath) WriteFile(byteS []byte) error {
	return ioutil.WriteFile(f.fspath, byteS, Perm)
}

// ReadDir reads the directory named by OsPath.Path() and returns a list of directory
// entries sorted by filename.
func (f *fsPath) ReadDir() ([]os.FileInfo, error) {
	fiS, err := ioutil.ReadDir(f.fspath)
	return fiS, err
}

/*
func TempDir(dir, prefix string) (name string, err error)
    TempDir creates a new temporary directory in the directory dir with a name
    beginning with prefix and returns the path of the new directory. If dir is
    the empty string, TempDir uses the default directory for temporary files
    (see os.TempDir). Multiple programs calling TempDir simultaneously will not
    choose the same directory. It is the caller's responsibility to remove the
    directory when no longer needed.

func TempFile(dir, prefix string) (f *os.File, err error)
    TempFile creates a new temporary file in the directory dir with a name
    beginning with prefix, opens the file for reading and writing, and returns
    the resulting *os.File. If dir is the empty string, TempFile uses the
    default directory for temporary files (see os.TempDir). Multiple programs
    calling TempFile simultaneously will not choose the same file. The caller
    can use f.Name() to find the pathname of the file. It is the caller's
    responsibility to remove the file when no longer needed.

*/

// PathMatchesList reports whether fsPath matches any of the patterns
// given (optionally) as os.ListSeparator separated lists (analysed via filepath.SplitList).
func (f *fsPath) PathMatchesList(list ...string) (matched bool, err error) {
	var patternS []string
	for _, patternList := range list {
		patternS = append(patternS, filepath.SplitList(patternList)...)
	}
	return f.PathMatches(patternS...)
}

// PathMatches reports whether fsPath matches any of the patterns.
func (f *fsPath) PathMatches(patterns ...string) (matched bool, err error) {
	return Match(f.String(), patterns...)
}

// BaseMatchesList reports whether base name of fsPath matches any of the patterns
// given (optionally) as os.ListSeparator separated lists (analysed via filepath.SplitList).
func (f *fsPath) BaseMatchesList(list ...string) (matched bool, err error) {
	var patternS []string
	for _, patternList := range list {
		patternS = append(patternS, filepath.SplitList(patternList)...)
	}
	return f.BaseMatches(patternS...)
}

// BaseMatches reports whether base name of fsPath matches any of the patterns.
func (f *fsPath) BaseMatches(patterns ...string) (matched bool, err error) {
	return Match(f.Base(), patterns...)
}

// BaseLessExt: name.Base() less name.Ext()
func (f *fsPath) BaseLessExt() string {
	return BaseLessExt(f.fspath)
}
