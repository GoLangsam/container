﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
	"sync"
)

type lazyStringMapper interface {
	performanceFriendly // lazy.go
	accessFriendly // get.go
	concurrencyFriendly // sync.go
	userFriendly // use.go
}

var _ lazyStringMapper = New() // Interface satisfied? :-)

type LazyStringMapper struct {
	val        map[string]fmt.Stringer // content: M() or S()
	m          map[string]string       // on-demand buffer for content as map of strings
	s          []string                // on-demand buffer for content as slice of strings
	l sync.Mutex                       // concurency included - we care for it - and hide it
}
// Note: m and s are set to nil (via lockVal) upon any eventual change to val,
// and -upon access e.g. via S()- becomes recreated - on demand! - via lazyS

// New - a creator - for good orders sake
//
// Note: no need to call me - I use lazyInit to care for myself
// Hint: just plug me into Your "type favourite structure{}" :-)
func New() *LazyStringMapper {
	d := new(LazyStringMapper)
	d.l.Lock()         // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	d.init()
	return d
}


