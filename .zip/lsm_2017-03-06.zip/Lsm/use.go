﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
)

type userFriendly interface {
	init() // internal
	Init()
	Len() int
	Get(key string) (fmt.Stringer, bool)
	set(key string, val fmt.Stringer)
	Del(key string)
}

var _ userFriendly = New() // Interface satisfied? :-)

func (d *LazyStringMapper) Len() int {
	return len(d.val)
}

// Accessors - internal - to be used with locked d

func (d *LazyStringMapper) init() {
	d.val = make(map[string]fmt.Stringer)
	d.m, d.s = nil, nil // (re)created on demand

}

// Accessors - concurrency safe

func (d *LazyStringMapper) Init() {
	d.LockNew()         // protect me, destroy my being valueable, and ...
	defer d.UnlockVal() // release me, let me go ...
	d.init()
}

func (d *LazyStringMapper) Get(key string) (fmt.Stringer, bool) {
	d.LockVal()         // protect me, destroy my being valueable, and ...
	defer d.UnlockVal() // release me, let me go ...
	c, ok := d.val[key]
	if !ok || c == nil {
		return nil, false
	}
	return c, true
}

func (d *LazyStringMapper) set(key string, val fmt.Stringer) {
	d.LockVal()         // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	d.val[key] = val
}

func (d *LazyStringMapper) Del(key string) {
	d.LockVal()         // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	delete(d.val, key)
}
