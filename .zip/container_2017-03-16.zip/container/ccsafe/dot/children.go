﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

type childrenFriendly interface {
	get(key string) (*Dot, bool)
	getChild(key string) *Dot
}

var _ childrenFriendly = New("Interface satisfied? :-)")

// get is internal accessor
func (d *Dot) get(key string) (*Dot, bool) {
	var c *Dot

	if x, ok := d.LookupV(key); !ok { // || c == nil ???
		return nil, false
	} else if c, ok = x.(*Dot); !ok {
		return nil, false // panic("Did not get type Dot from lsm")
	} else {
		return c, true
	}
}

// getChild returns the child named by key, and panics if wrong type was found
//
// Note:
// - the child is handled unsafe - use with locked value container only
// - a new child is created and linked, if need
// - if d:Get(key) returns wrong type, getChild panics
func (d *Dot) getChild(key string) *Dot {
	var c *Dot

	if x, ok := d.LookupV(key); !ok || x == nil {
		c = New(key)      // new child
		c.p = d           // set me as it's parent
		d.Assign(key, c)  // assign me to key
	} else if c, ok = x.(*Dot); !ok {
		panic("getChild: Did not Get type Dot!")
	}

	if c.p != d { // sanity check
		panic("getChild: Ups: I am *not* parent of child?!?") // TODO: better formatting
	}
	return c
}
