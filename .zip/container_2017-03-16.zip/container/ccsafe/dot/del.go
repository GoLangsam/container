﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

type removeFriendly interface {
	Deletes(vals ...string) *Dot            // Delete/remove vals from Content - given as strings
	DeleteM(vals ...map[string]string) *Dot // Delete/remove val from Content - given as maps of strings
	DeleteS(vals ...[]string) *Dot          // Delete/remove val from Content - given as slices of strings
}

var _ removeFriendly = New("Interface satisfied? :-)")

// Value modifiers - concurrency safe

func (d *Dot) Deletes(vals ...string) *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		d.Delete(val)
	}
	return d
}

func (d *Dot) DeleteM(vals ...map[string]string) *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		for k, v := range val {
			if c, ok := d.get(k); ok && c != nil { // for valid child k: delete v
				c.Delete(v)
			}
		}
	}
	return d
}

func (d *Dot) DeleteS(vals ...[]string) *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, val := range vals {
		for _, v := range val {
			d.Delete(v)
		}
	}
	return d
}
