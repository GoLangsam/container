﻿package dot

import (
	"do/dot"
)

// use package "path/filepath"

// filepath.Glob(path)
func (d *Dot)AddFilePathGlob() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddFilePathGlob(d)

	return d
}

// filepath.Walk(path, WalkFunc)
func (d *Dot)AddFileInfoWalk() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddFileInfoWalk(d)

	return d
}

// use package "io/ioutil"

// func ioutil.ReadFile(filename string) ([]byte, error)
func (d *Dot)SetReadFile() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.SetReadFile(d)

	return d
}

// func ioutil.WriteFile(filename string, data []byte, perm os.FileMode) error
func (d *Dot)DoWriteFile() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.DoWriteFile(d)

	return d
}

// func ioutil.ReadDir(dirname string) ([]os.FileInfo, error)
func (d *Dot)AddReadDir() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...

	_ = dot.AddReadDir(d)

	return d
}

/* TODO - maybe
func TempDir(dir, prefix string) (name string, err error)
func TempFile(dir, prefix string) (f *os.File, err error)
*/
