﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"sort"
)

// DoterS implements sort.Interface
type DoterS []Doter

func (k DoterS) Len() int           { return len(k) }
func (k DoterS) Less(i, j int) bool { return k[i].String() < k[j].String() }
func (k DoterS) Swap(i, j int)      { k[i], k[j] = k[j], k[i] }

var _ sort.Interface = new(DoterS)
