﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"sync"

	"container/ccsafe/tag/ami"
	"container/ccsafe/lsm"
)

var _ Doter = New("Interface satisfied?")

type Dot struct {
	*tag.TagAny                     // key
	*lsm.LazyStringerMap            // value(s)
	p                    *Dot // parent: Up(), Root(), Path(), DownS()
	home                 *Dot // home - never changes
	sync.Mutex                      // concurency included
}

// New returns what You need in order to keep a hand on me :-)
func New(key string) *Dot {
	dot := &Dot{
		tag.New(key),     // init key
		lsm.New(),        // init val
		nil,              // no parent
		nil,              // no home
		*new(sync.Mutex), // mutex
	}
	dot.home = dot // home - never changes
	return dot
}

// A is a helper method for templates - it adds, and returns an empty string
func (d *Dot) A(vals ...string) string {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	for _, v := range vals {
		d = d.add(v) // fullfill the promise
	}
	return ""
}

// G is a helper method for templates - it Get's the (eventually new!) child (key)
// change name to Dot? Dot to Dots?
func (d *Dot) G(key string) *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	return d.getChild(key)
}

/*
Locking - handling with "do/dot"
All calls into "do/dot" have d.Lock()
All callbacks into Dot used (via interface "do/dot.Dot")
are named "UnlockedXyz" and assume d.Lock is held
*/

// UnlockedGet is a helper method  - it returns the (eventually new!) child (key)
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *Dot) UnlockedGet(key string) (interface{}, bool) {
	//	d.Lock()         // protect me, and ...
	//	defer d.Unlock() // release me, let me go ...
	c := d.getChild(key)
	return c, true // bool avoids usage from templates!
}

// UnlockedAdd adds key to d, and adds variadic strings below key, and returns child "key"
//
// Note: It's 2nd arg (bool) intentionally avoids usage from templates!
func (d *Dot) UnlockedAdd(key string, val ...string) (interface{}, bool) {
	//	d.Lock()             // protect me, and ...
	//	defer d.Unlock()     // release me, let me go ...
	c := d.getChild(key) // get key
	c.Lock()             // protect it, and ...
	defer c.Unlock()     // release it, let it go ...
	c.add(val...)        // fullfill the promise
	return c, true       // bool avoids usage from templates!
}

// Doter shows the composition as interface
type Doter interface {
	StringFriendly      // see below
	tag.Friendly        // via "pannewitz.com/container/tag"
	lsm.Friendly        // via "pannewitz.com/container/lsm"
//	userFriendly        // => dot!	extend.go: AddMap AddStrings AddStringS
	childrenFriendly    // children.go
	navigatorFriendly   // navigate.go: Up Root Path DownS
	privacyFriendly     // content.go
	printerFriendly     // print.go: PrintTree
	concurrencyFriendly // sync.go
//	ErrorFriendly       // => dot!	error.go
	goFriendly
	//	ChildrenS() []Doter
}

/* TODO
doc.go
*/


type StringFriendly interface {
	setableFriendly    // set.go: Set/replace Content: Set SetS SetM
	extendableFriendly // add.go: Add/overwrite Content: Add AddS AddM
	removeFriendly     // del.go: Delete/remove vals from Content
}

var _ StringFriendly = New("Interface satisfied?")

type goFriendly interface {
	//	Sort([]Doter)
}

var _ goFriendly = New("Interface satisfied?")
