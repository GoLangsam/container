﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

type navigatorFriendly interface {
	parent() *Dot
	Back() *Dot
	Root() *Dot
	Path() []*Dot
	DownS() []*Dot
}

var _ navigatorFriendly = New("Interface satisfied? :-)")

// Navigators - concurrency safe

// parent returns the parent (or nil, if at root)
func (d *Dot) parent() *Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	return d.p
}

// Back returns the parent (or nil, if at root)
func (d *Dot) Back() *Dot {
	return d.parent()
}

// Root goes all the way Up() and returns the root - just in case You lost it :-)
func (d *Dot) Root() *Dot {
	// Note: our locking is delegated to up.parent()
	var root *Dot
	for up := d; up != nil; up = up.parent() {
		root = up
	}
	return root
}

// Path returns a slice from here up to the root
// Note: as the slice is returned bottom-up, may like to reverse it :-)
func (d *Dot) Path() []*Dot {
	// Note: our locking is delegated to up.parent()
	var ups []*Dot
	for up := d; up != nil; up = up.parent() {
		ups = append(ups, up)
	}
	return ups
}

func (d *Dot) DownS() []*Dot {
	d.Lock()         // protect me, and ...
	defer d.Unlock() // release me, let me go ...
	var dns []*Dot = make([]*Dot, 0, d.Len())
	for _, key := range d.S() { // children
		dns = append(dns, d.getChild(key))
	}
	return dns
}
