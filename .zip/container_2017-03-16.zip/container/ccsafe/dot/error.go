﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"errors"
)

type ErrorFriendly interface {
	SeeError(sender, place string, err error) bool
	SeeNotOk(sender, place string, ok bool, complain string) bool
}

var _ ErrorFriendly = New("Interface satisfied? :-)")

type notOkError error

func notOk(text string) notOkError {
	var n notOkError = errors.New(text)
	return n
}

func (d *Dot) dotError() *Dot {
	myName := "Error"
	return d.getChild(myName + ":")
}

func (d *Dot) dotNameTag(text string, tag interface{}) *Dot {
	c := d.getChild(text)
	c.Tag(tag)
	return c
}

func (d *Dot) dotErrorErr(sender, place string, err error) *Dot {
	_ = d.dotNameTag(sender + " encountered: " + err.Error() + " @ " + place, err)
	return d
}

func (d *Dot) dotErrorNok(sender, place string, err error) *Dot {
	_ = d.dotNameTag(sender + " found: " + err.Error() + " @ " + place, err)
	return d
}

// Helpers to handle an Error resp. NotOk complaint consistently

// If err!=nil, attach an error below "Error:" of d, and return true
//
// Note: d is assumed to be locked by caller!
func (d *Dot) SeeError(sender, place string, err error) bool {
	if err == nil { return false }

	d.Unlock()       // release me, temporarily ...
	defer d.Lock()   // and return me re-protected ...

	_ = d.dotError().dotErrorErr(sender, place, err)
	d.Tag("") // invalidate value of d

	return true
}

// If ok!=true, attach a not-ok complain below "Error:" of d, and return true
//
// Note: d is assumed to be locked by caller!
func (d *Dot) SeeNotOk(sender, place string, ok bool, complain string) bool {
	if ok == true { return false }

	d.Unlock()       // release me, temporarily ...
	defer d.Lock()   // and return me re-protected ...

	_ = d.dotError().dotErrorNok(sender, place, notOk(complain))
	// do *NOT* invalidate value of d

	return true
}
