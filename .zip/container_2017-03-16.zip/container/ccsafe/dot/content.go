﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

type privacyFriendly interface {
	add(vals ...string) *Dot            // add val as children to current content
	addM(val ...map[string]string) *Dot // add content named val: to any child named as key add content named as val[key]
}

var _ privacyFriendly = New("Interface satisfied? :-)")

// Value modifiers - internal - to be used with locked d

// add content named val
func (d *Dot) add(vals ...string) *Dot {
	for _, k := range vals {
		_ = d.getChild(k)
	}
	return d
}

// addM adds children named as key and adds content named as val[key]
//
// Note: as many childs may be added, the common parent (which is me) is returned
func (d *Dot) addM(val ...map[string]string) *Dot {
	for _, maps := range val {
		for k, v := range maps {
			c := d.getChild(k)
			_ = c.getChild(v)
		}
	}
	return d
}
