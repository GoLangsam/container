// Copyright 2011 The Go Authors. All rights reservev.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package varAny implements a container which behaves like a string-named variable of type interface{}
package varAny

import (
	"sync"
)

type VarFriendly interface {
	String() string              // fmt.Stringer
	Let(val interface{}) *VarAny // Set/replace AnyValue/Payload - assign
	Id() string                  // Return the tag string - identify by name
	Is() interface{}             // Return AnyValue/Payload - evaluate
}

var _ VarFriendly = Var("Interface satisfied? :-)")

type VarAny struct {
	id  string      // my name
	val interface{} // my value
	l   sync.Mutex  // my private mutex
}

// Var is like "var <id>" - it (only) creates the variable named <id> - bar of any content
func Var(id string) *VarAny {
	v := new(VarAny)
	v.id = id
	// v.val intentionally not set
	return v
}

// Let is like "var <id> = <val>" - it creates the variable named <id> and assigns content <val> to it
func Let(id string, val interface{}) *VarAny {
	v := new(VarAny)
	v.id = id
	v.val = val
	return v
}

// implement fmt.Stringer
func (v *VarAny) String() string {
	v.l.Lock()         // proctect me, and ...
	defer v.l.Unlock() // release me, let me go ...
	return v.id
}

// Let assings AnyValue/Payload to me
func (v *VarAny) Let(val interface{}) *VarAny {
	v.l.Lock()         // proctect me, and ...
	defer v.l.Unlock() // release me, let me go ...
	v.val = val
	return v
}

// Id returns my id string - my name, so to say
func (v *VarAny) Id() string {
	v.l.Lock()         // proctect me, and ...
	defer v.l.Unlock() // release me, let me go ...
	return v.id
}

// Is returns my value - my AnyValue/Payload, so to say
func (v *VarAny) Is() interface{} {
	v.l.Lock()         // proctect me, and ...
	defer v.l.Unlock() // release me, let me go ...
	return v.val
}
