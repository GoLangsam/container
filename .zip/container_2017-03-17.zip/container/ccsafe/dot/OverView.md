In Templates:
getters:
TAG .K

TAG .V [.String]
LSM .S
LSM .M - testen!

setters:
TAG: Tag(?)
StringMap - A(... ...)
StringMap - G

Add, AddS AddM derz. nicht, da kein return

Set&move down:
AddStrings AddStringS AddMap



container
	svp - StringValuePair - named constants
		String() string // fmt.Stringer
		K() string      // returns my Key
		V() interface{} // returns my Value

	tag - TagAny - named variables.
		String() string      // fmt.Stringer
		Tag(val interface{}) // Set/replace AnyValue/Payload
		K() string           // Return the tag string (shortcut for String())
		V() interface{}      // Return AnyValue/Payload
		TODO: make it use svp, and (try to) overload svp's accessors with locking

	lsm - LazyStringerMap
		TODO: make it use tag instead of fmt.Stringer; or do/nvp

		A(...string) ""
		G(key) string
		S() []keys
		
		AddStrings(key, ...string) - short for G(key) & A(...) 

	var - VarAny - named variables. TODO: make it use svp, and (try to) overload svp's accessors with locking
		String() string              // fmt.Stringer
		Let(val interface{}) *VarAny // Set/replace AnyValue/Payload - assign
		Id() string                  // Return the tag string - identify by name
		Is() interface{}             // Return AnyValue/Payload - evaluate


	TODO:
	ltag - LazyTag - a drop-in replacement for Tag which keeps it's "leaf" buffered for fast access
		or keeps the strings in a slice or stack ... and so emulating the recursive nature of named var's
		little tricky, as it may receive it's own kind as value - but then it would know due to type assertion,
		and can unpack it 
	
	

do
	nvp - NamedValuePair: interface {K|T|Id} {V|Is}, and recursive methods/functions hereon:
		Leaf, NameS, Path - accessors
		??? how to change the value (or it's type @ the bottom?)
		!!! Use Leaf & NameS to create a new one ? Or just an iterative Tag/Let(val interface{}) ?

	ssr - string Stringer