﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"fmt"
	"io"
	"os"
)

type OutputFriendly interface {
	out() io.Writer
	SetOutput(output io.Writer) // sets the destination for usage and error messages. If output is nil, os.Stderr is used.
	PutOut(msg ...interface{})  // prints msg's on a line to out()
}

var _ OutputFriendly = New("Interface satisfied? :-)")

// as found in "flag/flag.go"

func (d *Dot) out() io.Writer {
	if d.output == nil {
		return os.Stderr
	}
	return d.output
}

// SetOutput sets the destination for usage and error messages.
// If output is nil, os.Stderr is used.
func (d *Dot) SetOutput(output io.Writer) {
	d.output = output
}

// OutOut prints msg's on a line to out()
func (d *Dot) PutOut(msg ...interface{}) {
	fmt.Fprintln(d.out(), msg...)
}