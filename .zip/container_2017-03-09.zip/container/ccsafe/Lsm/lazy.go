// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

type PerformanceFriendly interface {
	forget()
	lazyInit()
	lazyS() []string
	lazyM() map[string]string
}

var _ PerformanceFriendly = New() // Interface satisfied? :-)

// helper to forget - "destroy my being valueable" :-)
func (d *LazyStringMapper) forget() {
	d.m, d.s = nil, nil // destroy my being valueable
}

// helper for init-on-demand
func (d *LazyStringMapper) lazyInit() {
	if d == nil {
		d = New()
	}
	if d.val == nil {
		d = d.UnsafeInit()
	}
}

// helper to rebuild and keep hold of val-map[keys] as sorted slice
func (d *LazyStringMapper) lazyS() []string {
	if d.s != nil {
		return d.s
	}
	d.s = sortM(d.lazyM())
	return d.s
}

// helper to rebuild and keep hold of val-map[keys] as map of strings
func (d *LazyStringMapper) lazyM() map[string]string {
	if d.m != nil {
		return d.m
	}
	m := make(map[string]string, d.Len())
	for key, val := range d.val {
		m[key] = val.String()
	}
	d.m = m
	return m
}
