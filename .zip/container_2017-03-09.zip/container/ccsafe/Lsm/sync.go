﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

// Note: this interface is exposed for godoc - only ;-)
type ConcurrencyFriendly interface {
	LockVal()   // Lock, and invalidate val
	LockNew()   // Lock & invalidate val, and (re)initialise val
	UnlockVal() // release me, let me go ...
}

var _ ConcurrencyFriendly = New() // Interface satisfied? :-)

// Lock & invalidate val, and (re)initialise val - to start afresh
func (d *LazyStringMapper) LockNew() {
	d.LockVal()        // protect me, and destroy my being valueable
	d = d.UnsafeInit() // restore me as being valueable (just: empty)
}

// Lock, and invalidate val
func (d *LazyStringMapper) LockVal() {
	d.lazyInit() // make sure I'm not nil
	d.l.Lock()   // protect me
	d.forget()   // destroy my being valueable
}

// Unlock val - please do not forget to defer me upon any use of LockXyz
func (d *LazyStringMapper) UnlockVal() {
	d.l.Unlock() // release me, let me go ...
}
