﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
)

// Note: this interface is exposed for godoc - only ;-)
type LockFriendly interface {
	// Unsafe: use, if already locked eg. via LockVal
	UnsafeAssign(key string, val fmt.Stringer) // use, if already locked eg. via LockVal
	UnsafeDel(key string)                      // use, if already locked eg. via LockVal
	UnsafeGet(key string) (fmt.Stringer, bool) // use, if already locked eg. via LockVal
}

var _ LockFriendly = New() // Interface satisfied? :-)

// Unsafe Accessors - use only after You locked me!

// Having locked me, Want my content reborn empty?
func (d *LazyStringMapper) UnsafeInit() *LazyStringMapper {
	d.val = make(map[string]fmt.Stringer)
	d.forget() // destroy my being valueable
	return d
}

// Having locked me, You want to let my content named "key" to be "val"?
func (d *LazyStringMapper) UnsafeAssign(key string, val fmt.Stringer) {
	d.forget() // destroy my being valueable
	d.val[key] = val
}

// Having locked me, You want my content named "key"?
func (d *LazyStringMapper) UnsafeGet(key string) (fmt.Stringer, bool) {
	if c, ok := d.val[key]; !ok { //|| c == nil
		return nil, false
	} else {
		return c, true
	}
}

// Having locked me, You want me to forget about name "key" (and it's related content)?
func (d *LazyStringMapper) UnsafeDel(key string) {
	d.forget() // destroy my being valueable
	delete(d.val, key)
}
