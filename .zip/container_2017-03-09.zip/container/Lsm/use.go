﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"

	"pannewitz.com/do/ssr"	// string Stringer
)

// I love to be easy - thus: I give You a simple API!
//  Create me with New, if You like - Note: No need, I'm friendly :-)
//  and Put stuff under it's own name, or Assign a name of Your choice,
//  and Get it back by it's name,
//  and Del some or Init all,
//  as You please :-)
// Note: this interface is exposed for godoc - only ;-)
type UserFriendly interface {
	Put(val fmt.Stringer)                // assign a Stringer to it's own name ""val.String()" as "key"
	AsSign(key string, val fmt.Stringer) // assign a Stringer to name "key"
	Assign(key string, val string)       // assign a string "val" to name "key"
	Get(key string) (fmt.Stringer, bool) // obtain content named "key"
	Del(key string)                      // forget name "key" (and related content, if any)
	Init() *LazyStringerMap              // (re)start afresh: no names, no content
	//
	Len() int // How many things do I contain right now?
}

var _ UserFriendly = New() // Interface satisfied? :-)

// Accessors

// Want my content reborn empty?
func (d *LazyStringerMap) Init() *LazyStringerMap {
	d.val = make(map[string]fmt.Stringer)
	d.forget() // destroy my being valueable

	return d
}

// You want to let my content be "val", named by it's own name "val.String()"?
func (d *LazyStringerMap) Put(val fmt.Stringer) {
	d.forget() // destroy my being valueable
	d.val[val.String()] = val
}

// You want to let my content named "key" to be the "val"-string?
func (d *LazyStringerMap) Assign(key string, val string) {
	d.forget() // destroy my being valueable
	d.val[key] = ssr.Stringer(val)
}

// You want to let my content named "key" to be the "val"-fmt.Stringer?
func (d *LazyStringerMap) AsSign(key string, val fmt.Stringer) {
	d.forget() // destroy my being valueable
	d.val[key] = val
}

// You want my content named "key"?
func (d *LazyStringerMap) Get(key string) (fmt.Stringer, bool) {
	if c, ok := d.val[key]; !ok { //|| c == nil
		return nil, false
	} else {
		return c, true
	}
}

// You want me to forget about name "key" (and it's related content)?
func (d *LazyStringerMap) Del(key string) {
	d.forget() // destroy my being valueable
	delete(d.val, key)
}

// How many things do I contain right now?
func (d *LazyStringerMap) Len() int {
	return len(d.val)
}
