﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
)

// I love to contain strings, named strings, named things, things which can name themselfs.
//	And I love to give them back to You, when You need 'em.
//	And also their names -as slice or map- as You need 'em.
//      And also sorted, or reversed, all for Your convenience.
// Note: this interface is exposed for godoc - only ;-)
type Friendly interface {
	AccessFriendly      // gets.go
	UserFriendly        // use.go
	PerformanceFriendly // lazy.go
}

var _ Friendly = New() // Interface satisfied? :-)

type LazyStringerMap struct {
	val map[string]fmt.Stringer // content: M() or S()
	m   map[string]string       // on-demand buffer for content as map of strings
	s   []string                // on-demand buffer for content as slice of strings
}

// Note: I forget() m and s upon any eventual change to val,
// and recreate -on demand!- e.g. via lazyS

// New - my creator - for good orders sake ;-)
//
// Note: no need to call me - I use lazyInit to care for myself :-)
//
// Hint: just plug me into Your "type favourite structure{}" :-)
//
func New() *LazyStringerMap {
	d := new(LazyStringerMap)
	d = d.Init()
	return d
}
