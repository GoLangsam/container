// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
)

// I love to be responsive :-)
//	Get my content as sorted slice: S or as map: M (or even as is: LSM)
// Note: this interface is exposed for godoc - only ;-)
type AccessFriendly interface {
	M() map[string]string         // return Content as map
	S() []string                  // return Content as sorted slice
	LSM() map[string]fmt.Stringer // return Content as is
}

var _ AccessFriendly = New() // Interface satisfied? :-)

// M returns the content as map[string]string
// Thus: {{ .M."output".S }} acesses the main map for key="output"
// and returns its content as a slice
func (d *LazyStringerMap) M() map[string]string {
	return d.lazyM() // fullfill the promise
}

// S returns the content as sorted slice
// Thus: {{ range .S }} walks the slice of the root's node content
func (d *LazyStringerMap) S() []string {
	return d.lazyS() // fullfill the promise
}

// LSM returns my complete content
func (d *LazyStringerMap) LSM() map[string]fmt.Stringer {
	return d.val
}
