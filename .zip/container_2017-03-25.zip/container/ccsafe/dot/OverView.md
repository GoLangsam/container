In Templates:
	getters:
	- TAG:[.String]		string
	- TAG: .K		string
	- TAG: .V		string
	- TAG: .GetV		interface{}

	- LSM: .S		[]string
	- LSM: .M - testen!
	- LSM: .Range		[]interface{}
	- LSM: .Lookup(key)	string

	- Dot: .  		*Dot

	setters:
	- TAG: .Tag(?)

	- Dot: .A(vals ...string)
	- Dot: .KV(key, val string)

	Set only:
	- Dot: Add, AddS AddM

	Set&move down:
	- Dot: .G
	- LSM: AddStrings AddStringS AddMap



container
	TODO:
	ltag - LazyTag - a drop-in replacement for Tag which keeps it's "leaf" buffered for fast access
		or keeps the strings in a slice or stack ... and so emulating the recursive nature of named var's
		little tricky, as it may receive it's own kind as value - but then it would know due to type assertion,
		and can unpack it 

do
	nvp - NamedValuePair: interface {K|T|Id} {V|Is}, and recursive methods/functions hereon:
		Leaf, NameS, Path - accessors
		??? how to change the value (or it's type @ the bottom?)
		!!! Use Leaf & NameS to create a new one ? Or just an iterative Tag/Let(val interface{}) ?
