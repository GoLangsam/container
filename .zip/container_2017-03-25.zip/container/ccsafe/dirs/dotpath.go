package dirs

import (
	"container/list"
	"os"
	"path"
	"path/filepath"
	"strings"
)

const (
	empty   = ``
	dot     = `.`
	slash   = `/`
	listsep = os.PathListSeparator
)

func init() { // some paranoid sanity checks ;-)
	if len(empty) != 0 {
		panic("My empty '" + empty + "' has non-zero length!")
	}

	if dot != path.Clean(empty) {
		panic("My dot '" + dot + "' differs from '" + path.Clean(empty) + "' = path.Clean(empty)")
	}

	if slash != path.Clean(slash+slash+slash+slash+slash+slash+slash+slash+slash+slash+slash+slash+slash) {
		panic("My slash '" + slash + "' differs from '" + path.Clean(slash+slash) + "' = path.Clean(slash+slash+...)")
	}
}

type DotPathS []DotPath

type DotPath struct {
	origText string     // the original input - never touched
	baseL    *list.List // bottom-up list of elements
	baseS    []PathBase // bottom-up list of elements
	butDots  bool       // anything but dots?
}

func NewDotPath(pathname string) *DotPath {
	dp := new(DotPath)
	dp.origText = filepath.ToSlash(pathname)
	dp.baseL = list.New()
	dp.baseS = []PathBase{}
	return dp.fill()
}

func (dp *DotPath) fill() *DotPath {

	for _, split := range PathSplitter(dp.origText) {
		head, tail := SplitSuffix(split, dot)
		if len(head) > 0 {
			dp.butDots = true
		}

		baseS := PathDotTailor(head, tail)
		for i := len(baseS); i > 0; i-- {
			dp.baseS = append(dp.baseS, PathBase(baseS[i-1]))
		}
	}
	return dp
}

// IsValidOsPath - returns true unless os.Stat returns an error (of type *PathError)
func (dp *DotPath) IsValidOsPath() bool {
	_, err := os.Stat(filepath.FromSlash(dp.Path()))
	return (err == nil)
}

// String - returns the path - ignoring any ...
func (dp *DotPath) String() (pathName string) {
	nameS := []string{}
	for i := len(dp.baseS); i > 0; i-- {
		nameS = append(nameS, dp.baseS[i-1].String())
	}
	return strings.Join(nameS, "/")
}

// Path - returns the path - ignoring any single . and triple ... dot.
func (dp *DotPath) Path() (pathName string) {
	var parts int

	// use a quick little buffer
	var buff string
	clear := func() {
		buff = ""
	}
	flush := func() {
		if len(buff) > 0 {
			pathName = path.Join(pathName, buff)
			parts++
			clear()
		}
	}
	push := func(dp PathBase) {
		if len(buff) > 0 {
			flush()
		}
		buff = dp.String()
	}

	for i := len(dp.baseS); i > 0; i-- {
		base := dp.baseS[i-1]

		switch {
		case base.Down(): //
		case base.Skip():
			if parts == 0 && len(buff) == 0 {
				push(base)
			}
		case base.GoUp():
			if parts > 0 || (len(buff) > 0 && buff != dot) {
				clear()
			} else {
				push(base)
			}
		default:
			push(base)
		}
	}

	flush()
	return pathName
}

/* Note: we could do 'cleaner':
- Path - the path as intended - cleaned, and ignoring any ...
	baseS from last to first
	- skip any Down
		- remember in quick
	- skip any Skip after first
	- skip any (prev+dotdot)
		- remember in clean
	compare path.Clean(quick) == clean


*/

// RecursePathS returns any (partial) path which ends in a Down ...
func (dp *DotPath) RecursePathS() (pathS []string) {
	var pathName string
	for i := len(dp.baseS); i > 0; i-- {
		base := dp.baseS[i-1]
		switch {
		case base.Skip(): //
		case base.Down(): //
			pathS = append(pathS, pathName)
		default:
			pathName = path.Join(pathName, base.String())
		}
	}
	return pathS
}

// InspectPathS returns any (partial) path which is followed by some GoUp ..
func (dp *DotPath) InspectPathS() (pathS []string) {

	var pathName string
	var GoUps = []string{}
	var done bool
	for i := len(dp.baseS); i > 0; i-- {
		base := dp.baseS[i-1]
		switch {
		case base.Skip():
			//
		case base.Down():
			//
		case base.GoUp():
			if done {
				pathName = path.Join(pathName, base.String())
			} else {
				GoUps = append(GoUps, base.String())
			}
		default:
			done = true
			pathName = path.Join(pathName, base.String())
		}
	}

	for upS := GoUps; len(upS) > 0; upS = upS[:len(upS)] {
		pathS = append(pathS, path.Join(pathName, path.Join(upS...)))
	}
	pathS = append(pathS, path.Clean(pathName))
	return pathS
}

/*
Note: We focus on 'trailing' dots!

base/../foo/../bar/..	=> bar/.. & bar

Otherwise we get things like these, with duplicate visits:

base					=> base)
base/..					=> .)
base/../foo/			=> foo)
base/../foo/..			=> .	which we had before!)
base/../foo/../bar		=> bar
base/../foo/../bar/..	=> .	which we had before!)

root/base/../foo/../../bar/../..

root/base					 		=> root/base
root/base/..						=> root
root/base/../foo					=> root/foo
root/base/../foo/..					=> root	which we had before!)
root/base/../foo/../..				=> .
root/base/../foo/../../bar			=> bar
root/base/../foo/../../bar/..		=> .		which we had before!)
root/base/../foo/../../bar/../..	=> ..

*/
