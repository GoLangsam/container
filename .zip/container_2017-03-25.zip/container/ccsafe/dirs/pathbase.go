﻿package dirs

const (
	singledot = dot // just another name
	doubledot = dot + dot
	tripledot = dot + dot + dot
)

// PathBase represents an element of a path string
type PathBase string

func (pb PathBase) String() string {
	return string(pb)
}

func (pb PathBase) Skip() bool {
	return (pb == singledot)
}

func (pb PathBase) GoUp() bool {
	return (pb == doubledot)
}

func (pb PathBase) Down() bool {
	return (pb == tripledot)
}
