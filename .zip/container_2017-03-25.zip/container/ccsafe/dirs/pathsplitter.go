package dirs

import (
	"path"
	"strings"
)

// StripSuffix returns text less suffix.
// If text does not end on suffix, text is returned unchanged.
func StripSuffix(text, suffix string) string {
	if strings.HasSuffix(text, suffix) {
		return text[:len(text)-len(suffix)]
	}
	return text
}

// SplitSuffix looks for all occurences of suffix and
// returns them as tail, and text less them as head.
// Invariant: len(text) == len(head) + len(tail)
func SplitSuffix(text, suffix string) (head, tail string) {
	head = text

	lens := len(suffix)
	if lens > 0 {
		for pos := len(text) - lens; pos >= 0; pos = len(head) - lens {
			if head[pos:] == suffix {
				head = head[:pos]
				tail = tail + suffix
			} else {
				break
			}
		}
	}
	return head, tail
}

// OneTripleAnyPairs - a helper to get e.g. '........' as '... .. .. .'
// Invariant: len(text) == len(segmentS)
func OneTripleAnyPairs(text string) (segmentS []string) {
	dotsleft := text          // what's left
	lengleft := len(dotsleft) // how many

	if lengleft > 2 { // take Triple ... once
		segmentS = append(segmentS, dotsleft[:3])
		dotsleft = dotsleft[3:]
		lengleft = lengleft - 3 // 2+1
	}

	for lengleft > 1 { // take Double ..
		segmentS = append(segmentS, dotsleft[:2])
		dotsleft = dotsleft[2:]
		lengleft = lengleft - 2 // 1+1
	}

	for lengleft > 0 { // take Single . (should be only one, if any)
		segmentS = append(segmentS, dotsleft[:1])
		dotsleft = dotsleft[1:]
		lengleft = lengleft - 1 // 0+1
	}
	return segmentS
}

// PathDotTailor returns a slice of strings each representing a valid node / element / PathBase,
// or a triple-dot as indicator for a full tree of subdirectories.
func PathDotTailor(head, tail string) []string {
	lenhead := len(head)
	lentail := len(tail)
	if lentail < 1 {
		return []string{head}
	}

	if lentail != strings.Count(tail, dot) {
		panic("PathDotTailor: Expect tail to consist only of dots - but found:" + tail)
	}

	if lenhead == 0 {
		return OneTripleAnyPairs(tail)
	} else {
		l := []string{head + string(tail[0])}
		l = append(l, OneTripleAnyPairs(tail[1:])...)
		return l
	}
}

// PathSplitter returns a slice of strings each representing a node / element / PathBase.
// The order is last-first / bottom up / reversed. All slashes are gone.
func PathSplitter(pth string) (pathBaseS []string) {
	var dir, file string
	dir, file = pth, empty

	for len(dir) > 0 {
		dir, file = path.Split(dir)
		dir = StripSuffix(dir, slash)

		pathBaseS = append(pathBaseS, file)
	}
	return pathBaseS
}
