// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"fmt"
)

type PrinterFriendly interface {
	PrintTree(prefix ...string) *Dot // prints the tree, one line per node, each prefixed by prefix and indented with tab "\t"
}

var _ PrinterFriendly = New("Interface satisfied?")

const tab = "\t"

// PrintTree prints the tree, one line per node, each prefixed by prefix and indented with tab "\t"
func (d *Dot) PrintTree(prefix ...string) *Dot {
	var indent string
	for i, pre := range prefix {
		if i == 0 {
			indent = indent + pre
		} else {
			indent = indent + tab + pre
		}

	}
	printTree(d, tab, indent)
	return d
}

func printTree(d *Dot, delim, indent string) {
	if d == nil {
		return
	}
	id := indent + delim
	fmt.Println(id, d.String())
	for _, m := range d.DownS() {
		printTree(m, delim, id)
	}
}
