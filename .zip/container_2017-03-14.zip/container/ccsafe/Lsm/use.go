﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
)

// Note: this interface is exposed for godoc - only ;-)
type UserFriendly interface {
	Assign(key string, val fmt.Stringer)
	Get(key string) (fmt.Stringer, bool)
	Del(key string)
	Init() *LazyStringMapper
	//
	Len() int
}

var _ UserFriendly = New() // Interface satisfied? :-)

// Accessors - concurrency safe

// Want my content reborn empty?
func (d *LazyStringMapper) Init() *LazyStringMapper {
	d.LockVal()         // protect me, destroy my being valueable, and ...
	defer d.UnlockVal() // release me, let me go ...
	d = d.UnsafeInit()
	return d
}

// You want to let my content named "key" to be "val"?
func (d *LazyStringMapper) Assign(key string, val fmt.Stringer) {
	d.LockVal()        // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	d.UnsafeAssign(key, val)
}

// You want my content named "key"?
func (d *LazyStringMapper) Get(key string) (fmt.Stringer, bool) {
	d.LockVal()         // protect me, destroy my being valueable, and ...
	defer d.UnlockVal() // release me, let me go ...
	return d.UnsafeGet(key)
}

// You want me to forget about name "key" (and it's related content)?
func (d *LazyStringMapper) Del(key string) {
	d.LockVal()        // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	d.UnsafeDel(key)
}

// How many things do I contain right now?
func (d *LazyStringMapper) Len() int {
	d.LockVal()        // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	return len(d.val)
}
