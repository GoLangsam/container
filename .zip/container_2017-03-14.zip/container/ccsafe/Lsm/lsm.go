﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"
	"sync"
)

// Note: this interface is exposed for godoc - only ;-)
type LazyStringMapperFriendly interface {
	AccessFriendly      // get.go
	UserFriendly        // use.go
	LockFriendly        // unsafe.go
	ConcurrencyFriendly // sync.go
	PerformanceFriendly // lazy.go
}

var _ LazyStringMapperFriendly = New() // Interface satisfied? :-)

// I love to be easy - thus: I give You a simple API!
//	Create me with New, and Assign or Get, and Del or Init as You please :-)
//
// I love to be responsive :-)
//	Get my content as sorted slice: S or as map: M (or even as is: LSM)
//
// I love to be fast :-)
//  Thus: I memoize answers about my content, and about when to forget my memos
//
// I love to be lazy - do not like to do things over and over again.
//	Thus: only when You ask the question, then, on Your demand, so to say
//	do I prepare the answer for such certain question about my content. ;-)
//
// I love to be concurrency-safe :-)
//  Thus: I always protect myself - except for my.Unsafe-methods, of course :-)
//
// I love to be concurrency-friendly :-)
//	Use LockVal to modify my content. (or simply LockNew to start afresh (with Init())
//	And -please!- do not forget to defer my.UnlockVal ;-)
//
type LazyStringMapper struct {
	val map[string]fmt.Stringer // content: M() or S()
	m   map[string]string       // on-demand buffer for content as map of strings
	s   []string                // on-demand buffer for content as slice of strings
	l   sync.Mutex              // concurency included - we care for it - and hide it
}

// Note: I forget() m and s upon any eventual change to val,
// and recreate -on demand!- e.g. via lazyS

// New - my creator - for good orders sake ;-)
//
// Note: no need to call me - I use lazyInit to care for myself :-)
//
// Hint: just plug me into Your "type favourite structure{}" :-)
//
func New() *LazyStringMapper {
	d := new(LazyStringMapper)
	d.l.Lock()         // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	d = d.UnsafeInit()
	return d
}

// LSM returns my complete content
func (d *LazyStringMapper) LSM() map[string]fmt.Stringer {
	d.l.Lock()         // protect me, destroy my being valueable, and ...
	defer d.l.Unlock() // release me, let me go ...
	return d.val
}
