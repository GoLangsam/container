﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package lsm

import (
	"fmt"

	"do/ssr"	// string Stringer
)

// I love to be easy - thus: I give You a simple API!
//  Create me with New, if You like - Note: No need, I'm friendly :-)
//  and PutV a fmt.Stringer under it's own name, or AsSign a name of Your choice,
//  and LookupV it's value (a fmt.Stringer) back by it's name,
//  and Init to use me afresh,
//  as You please :-)
// Note: this interface is exposed for godoc - only ;-)
type UserFriendly interface {
	PutV(val fmt.Stringer)  *LazyStringerMap  // assign a Stringer to it's own name ""val.String()" as "key"
	AssignV(key string, val fmt.Stringer)  *LazyStringerMap // assign a Stringer to name "key"
	LookupV(key string) (fmt.Stringer, bool) // obtain content named "key" - as fmt.Stringer (or nil, false)
	Init() *LazyStringerMap              // (re)start afresh: no names, no content
	//
	Len() int // How many things do I contain right now?
}

var _ UserFriendly = New() // Interface satisfied? :-)

// I love to be easy to use - not only in templates :-)
//  Put a string under it's own name, or Assign a name of Your choice to another string,
//  Assign a value (as string) to it's name (as key),
//  Lookup it's value string back by it's name,
//  Del a key, if You don't need it any more
//  as You please :-)
// Note: this interface is exposed for godoc - only ;-)
type TemplateFriendly interface {
	Put(val string)  *LazyStringerMap  // assign a Stringer to it's own name ""val.String()" as "key"
	Assign(key string, val string)  *LazyStringerMap  // assign a string "val" to name "key"
	Lookup(key string) string             // obtain content named "key" - as (eventually empty) string
	Delete(key string) *LazyStringerMap     // forget name "key" (and related content, if any)
}

var _ TemplateFriendly = New() // Interface satisfied? :-)

// Accessors

// Want my content reborn empty?
func (d *LazyStringerMap) Init() *LazyStringerMap {
	d.val = make(map[string]fmt.Stringer)
	d.s = make([]string, 0, 16)
	d.m = nil
	d.forget() // destroy my being valueable, if need
	return d
}

// You want to let my content be "val", named by it's own name "val"?
func (d *LazyStringerMap) Put(val string) *LazyStringerMap {
	d.val[val] = ssr.Stringer(val)
	d.forget() // destroy my being valueable, if need
	return d
}

// You want to let my content be "val", named by it's own name "val.String()"?
func (d *LazyStringerMap) PutV(val fmt.Stringer) *LazyStringerMap {
	d.val[val.String()] = val
	d.forget() // destroy my being valueable, if need
	return d
}

// You want to let my content named "key" to be the "val"-string?
func (d *LazyStringerMap) Assign(key string, val string) *LazyStringerMap {
	d.val[key] = ssr.Stringer(val)
	d.forget() // destroy my being valueable, if need
	return d
}

// You want to let my content named "key" to be the "val"-fmt.Stringer?
func (d *LazyStringerMap) AssignV(key string, val fmt.Stringer) *LazyStringerMap {
	d.val[key] = val
	d.forget() // destroy my being valueable, if need
	return d
}

// You want my content named "key" - as (eventually empty) stringer
func (d *LazyStringerMap) Lookup(key string) string {
	if c, ok := d.val[key]; !ok { //|| c == nil
		return ""
	} else {
		return c.String()
	}
}

// You want my content named "key" - a fmt.Stringer?
func (d *LazyStringerMap) LookupV(key string) (fmt.Stringer, bool) {
	if c, ok := d.val[key]; !ok { //|| c == nil
		return nil, false
	} else {
		return c, true
	}
}

// You want me to forget about name "key" (and it's related content)?
func (d *LazyStringerMap) Delete(key string) *LazyStringerMap {
	delete(d.val, key)
	d.forget() // destroy my being valueable, if need
	return d
}

// How many things do I contain right now?
func (d *LazyStringerMap) Len() int {
	return len(d.val)
}
