﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.

package container

// ==============================================================

type list struct {
	root	string
	data	[]string
}

// X returns the cross product of some lists
// recursivlely as X2 ( first, X ( dims.next ) )
func X ( dims... *list ) ( *list  ) {

	var ret *list

	if len(dims) > 0 { ret = dims[0] }
	if len(dims) > 1 { ret = X2 ( ret, X ( dims[1:]... ) ) }
	return ret
}


// X2 returns the cross product of two lists as a new list (with headers per dimension)
func X2 ( cols, rows *list ) ( *list  ) {

	newcap := 1 * ( len( rows.data ) + 1 ) * ( len( cols.data ) + 1 )

	var ret list
	ret.root = cols.root + "|" + rows.root

	ret.data = make ([]string, 0, newcap )

	for _, e := range cols.data  {
		ret.data = append ( ret.data , cols.root + "-" + e ) // row root for col
	}

	for _, r := range rows.data  {
		for c, e := range cols.data  {
			if c == 0 { ret.data = append ( ret.data , rows.root + "-" + r ) } // row root for row
			var what = e + "|" + r
			ret.data = append ( ret.data , what )	// Point
		}
	}

	return &ret
}
